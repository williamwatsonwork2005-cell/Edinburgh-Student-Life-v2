import { Link, useRouterState } from "@tanstack/react-router";
import {
  CalendarDays,
  Users,
  Tag,
  Home,
  MapPin,
  Sparkles,
  PartyPopper,
  LifeBuoy,
  Briefcase,
  GraduationCap,
  HeartHandshake,
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from "@/components/ui/sidebar";

const campusItems = [
  { title: "Ask Caledon", url: "/assistant", icon: Sparkles },
  { title: "Planner", url: "/", icon: CalendarDays },
  { title: "Events map", url: "/events", icon: PartyPopper },
  { title: "Societies", url: "/societies", icon: Users },
  { title: "Bookings", url: "/bookings", icon: MapPin },
];

const livingItems = [
  { title: "Accommodation", url: "/accommodation", icon: Home },
  { title: "Flatmate finder", url: "/flatmates", icon: HeartHandshake },
  { title: "Deals", url: "/deals", icon: Tag },
];

const futureItems = [
  { title: "Work", url: "/work", icon: Briefcase },
  { title: "Careers", url: "/careers", icon: GraduationCap },
];

const supportItems = [{ title: "Help & Safety", url: "/help", icon: LifeBuoy }];

export function AppSidebar() {
  const pathname = useRouterState({ select: (r) => r.location.pathname });
  const isActive = (url: string) => (url === "/" ? pathname === "/" : pathname.startsWith(url));

  return (
    <Sidebar collapsible="icon">
      {/* Tartan accent strip on the left edge */}
      <div
        className="absolute inset-y-0 left-0 w-1.5 tartan-strip pointer-events-none"
        aria-hidden
      />
      <SidebarHeader className="px-3 py-4">
        <div className="flex items-center gap-2">
          {/* University of Edinburgh crest — green tartan with a stylised UoE monogram */}
          <div
            className="h-10 w-10 rounded-md tartan-band shadow-sm flex items-center justify-center relative overflow-hidden"
            aria-hidden
          >
            <div className="absolute inset-0.5 rounded-sm bg-sidebar/85 flex items-center justify-center">
              <span className="font-display text-base text-sidebar-primary leading-none">UoE</span>
            </div>
          </div>
          <div className="flex flex-col leading-tight group-data-[collapsible=icon]:hidden">
            <span className="font-display text-xl text-sidebar-primary">Caledon</span>
            <span className="text-[11px] uppercase tracking-widest text-sidebar-foreground/60">
              Edinburgh edition
            </span>
          </div>
        </div>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Campus</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {campusItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild isActive={isActive(item.url)}>
                    <Link to={item.url} className="flex items-center gap-2">
                      <item.icon className="h-4 w-4" />
                      <span>{item.title}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
        <SidebarGroup>
          <SidebarGroupLabel>Living</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {livingItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild isActive={isActive(item.url)}>
                    <Link to={item.url} className="flex items-center gap-2">
                      <item.icon className="h-4 w-4" />
                      <span>{item.title}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
        <SidebarGroup>
          <SidebarGroupLabel>Future</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {futureItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild isActive={isActive(item.url)}>
                    <Link to={item.url} className="flex items-center gap-2">
                      <item.icon className="h-4 w-4" />
                      <span>{item.title}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
        <SidebarGroup>
          <SidebarGroupLabel>Support</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {supportItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild isActive={isActive(item.url)}>
                    <Link to={item.url} className="flex items-center gap-2">
                      <item.icon className="h-4 w-4" />
                      <span>{item.title}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  );
}
