import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { useProfile, STAGE_LABEL, type StudentStage } from "@/lib/profile";

export function OnboardingDialog() {
  const { profile, setProfile, hydrated } = useProfile();
  const [open, setOpen] = useState(false);
  const [stage, setStage] = useState<StudentStage>("year1");

  useEffect(() => {
    if (hydrated && !profile) setOpen(true);
  }, [hydrated, profile]);

  const handleSave = () => {
    setProfile({ stage });
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display text-2xl">Welcome to Caledon</DialogTitle>
          <DialogDescription>
            Tell us where you're at so we can tailor accommodation, societies and bookings to you.
          </DialogDescription>
        </DialogHeader>
        <RadioGroup value={stage} onValueChange={(v) => setStage(v as StudentStage)} className="gap-3 py-2">
          {(Object.keys(STAGE_LABEL) as StudentStage[]).map((s) => (
            <div key={s} className="flex items-center gap-3 rounded-md border border-border p-3 hover:bg-accent/40 transition">
              <RadioGroupItem value={s} id={s} />
              <Label htmlFor={s} className="cursor-pointer flex-1">{STAGE_LABEL[s]}</Label>
            </div>
          ))}
        </RadioGroup>
        <DialogFooter>
          <Button onClick={handleSave} className="w-full">Continue</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
