import type { Weekday } from "@/data/societies";

export type EventCategory =
  | "Nightlife"
  | "Live music"
  | "Comedy"
  | "Society"
  | "Sport"
  | "Culture"
  | "Varsity"
  | "Pro sport";

export type CampusEvent = {
  id: string;
  name: string;
  venue: string;
  area: string;
  day: Weekday;
  start: string;
  category: EventCategory;
  blurb: string;
  fixrUrl?: string;
  ticketsUrl?: string;
  x: number;
  y: number;
};

export const EVENTS: CampusEvent[] = [
  // Nightlife — student staples
  {
    id: "whynot-wed",
    name: "WhyNot Wednesdays",
    venue: "Why Not?",
    area: "George Street",
    day: "Wed",
    start: "22:30",
    category: "Nightlife",
    blurb: "Edinburgh's biggest midweek student night. Cheap drinks, big tunes, queue forms early.",
    fixrUrl: "https://fixr.co/search?query=whynot+edinburgh",
    x: 48, y: 38,
  },
  {
    id: "hive-monday",
    name: "Trash Mondays",
    venue: "The Hive",
    area: "Cowgate",
    day: "Mon",
    start: "23:00",
    category: "Nightlife",
    blurb: "£1 drinks, indie/pop floor. The classic post-lecture decompress.",
    fixrUrl: "https://fixr.co/search?query=hive+edinburgh",
    x: 55, y: 55,
  },
  {
    id: "subway-fri",
    name: "Subway Cowgate Friday",
    venue: "Subway",
    area: "Cowgate",
    day: "Fri",
    start: "22:00",
    category: "Nightlife",
    blurb: "Dive bar energy. Rock and metal floor downstairs.",
    fixrUrl: "https://fixr.co/search?query=subway+cowgate",
    x: 54, y: 56,
  },
  {
    id: "bongo",
    name: "Bongo Club Headset",
    venue: "The Bongo Club",
    area: "Cowgate",
    day: "Sat",
    start: "23:00",
    category: "Nightlife",
    blurb: "Heavier electronic night. Drum & bass and UKG rotation.",
    fixrUrl: "https://fixr.co/search?query=bongo+club+edinburgh",
    x: 57, y: 56,
  },
  {
    id: "sneaky-thu",
    name: "Sneaky Pete's Live",
    venue: "Sneaky Pete's",
    area: "Cowgate",
    day: "Thu",
    start: "20:00",
    category: "Live music",
    blurb: "Tiny, sweaty, brilliant. Touring indie acts and local DJs every week.",
    fixrUrl: "https://fixr.co/search?query=sneaky+petes",
    x: 56, y: 56,
  },
  {
    id: "potterrow-bigcheese",
    name: "Big Cheese at Potterrow",
    venue: "Potterrow (EUSA)",
    area: "Bristo Square",
    day: "Sat",
    start: "23:00",
    category: "Nightlife",
    blurb: "EUSA's flagship Saturday — cheese, cheap pints, students-only. The iconic Edinburgh night out.",
    fixrUrl: "https://fixr.co/search?query=big+cheese+potterrow",
    x: 49, y: 60,
  },
  {
    id: "liquid-rooms-rave",
    name: "Liquid Rooms — Garage night",
    venue: "Liquid Rooms",
    area: "Victoria Street",
    day: "Fri",
    start: "23:00",
    category: "Nightlife",
    blurb: "House and garage. Bigger room than the Cowgate dives — closer to a proper club feel.",
    fixrUrl: "https://fixr.co/search?query=liquid+rooms+edinburgh",
    x: 46, y: 51,
  },

  // Live music & culture
  {
    id: "usher-orchestra",
    name: "Royal Scottish National Orchestra",
    venue: "Usher Hall",
    area: "Lothian Road",
    day: "Fri",
    start: "19:30",
    category: "Live music",
    blurb: "Student tickets from £12. World-class programming in one of Britain's best concert halls.",
    ticketsUrl: "https://www.usherhall.co.uk/whats-on",
    x: 34, y: 50,
  },
  {
    id: "filmhouse",
    name: "Cameo late screening",
    venue: "Cameo Cinema",
    area: "Tollcross",
    day: "Fri",
    start: "21:45",
    category: "Culture",
    blurb: "Cult late-night picks. Student tickets £6.",
    x: 36, y: 60,
  },
  {
    id: "kings-theatre",
    name: "Touring play (varies)",
    venue: "King's Theatre",
    area: "Tollcross",
    day: "Wed",
    start: "19:30",
    category: "Culture",
    blurb: "West End tours, opera and ballet. £10 student standby an hour before curtain.",
    ticketsUrl: "https://www.capitaltheatres.com",
    x: 35, y: 62,
  },

  // Comedy
  {
    id: "monkey-barrel",
    name: "Monkey Barrel New Material",
    venue: "Monkey Barrel Comedy",
    area: "Blair Street",
    day: "Tue",
    start: "19:30",
    category: "Comedy",
    blurb: "Cheap tickets, tomorrow's headliners trying new jokes tonight.",
    fixrUrl: "https://fixr.co/search?query=monkey+barrel",
    x: 53, y: 53,
  },
  {
    id: "stand-comedy",
    name: "The Stand Comedy Club",
    venue: "The Stand",
    area: "York Place",
    day: "Sat",
    start: "21:00",
    category: "Comedy",
    blurb: "Saturday late-night line-up — usually four to five acts and a compere. Student rate available.",
    ticketsUrl: "https://www.thestand.co.uk",
    x: 50, y: 28,
  },

  // Society / EUSA
  {
    id: "teviot-quiz",
    name: "Teviot Pub Quiz",
    venue: "Teviot Row House",
    area: "Bristo Square",
    day: "Tue",
    start: "20:00",
    category: "Society",
    blurb: "EUSA's weekly quiz at the world's oldest purpose-built student union.",
    x: 50, y: 62,
  },

  // Sport — student
  {
    id: "arthurs-sun",
    name: "Arthur's Seat sunrise hike",
    venue: "Arthur's Seat",
    area: "Holyrood",
    day: "Sun",
    start: "06:30",
    category: "Sport",
    blurb: "Hillwalking Society's weekly easy hike. All abilities.",
    x: 72, y: 55,
  },
  {
    id: "peffermill-rugby",
    name: "Men's Rugby BUCS fixture",
    venue: "Peffermill Playing Fields",
    area: "Peffermill",
    day: "Wed",
    start: "14:00",
    category: "Sport",
    blurb: "Wednesday afternoon home games. Free to spectate, decent pitch-side atmosphere.",
    x: 80, y: 70,
  },
  {
    id: "peffermill-hockey",
    name: "Women's Hockey BUCS fixture",
    venue: "Peffermill astroturf",
    area: "Peffermill",
    day: "Wed",
    start: "14:00",
    category: "Sport",
    blurb: "BUCS league hockey. Edinburgh's hockey teams consistently challenge for the top of the table.",
    x: 81, y: 71,
  },

  // Varsity
  {
    id: "varsity-rugby",
    name: "Scottish Varsity — Rugby",
    venue: "Murrayfield BT Murrayfield",
    area: "Murrayfield",
    day: "Wed",
    start: "19:30",
    category: "Varsity",
    blurb: "Edinburgh vs St Andrews, played annually at the national stadium. Tickets sell out in a week.",
    ticketsUrl: "https://www.eusu.ed.ac.uk/about/sports-union/",
    x: 12, y: 32,
  },
  {
    id: "varsity-football",
    name: "Varsity Football",
    venue: "Peffermill",
    area: "Peffermill",
    day: "Sat",
    start: "14:00",
    category: "Varsity",
    blurb: "Annual Edinburgh vs Heriot-Watt football fixture. Free for students with matric card.",
    x: 80, y: 72,
  },

  // Pro sport
  {
    id: "edinburgh-rugby",
    name: "Edinburgh Rugby home game",
    venue: "Hive Stadium",
    area: "Murrayfield",
    day: "Fri",
    start: "19:45",
    category: "Pro sport",
    blurb: "URC and Champions Cup home matches. Student season tickets are excellent value.",
    ticketsUrl: "https://www.edinburghrugby.org",
    x: 13, y: 30,
  },
  {
    id: "scotland-rugby",
    name: "Scotland Six Nations",
    venue: "Murrayfield Stadium",
    area: "Murrayfield",
    day: "Sat",
    start: "16:45",
    category: "Pro sport",
    blurb: "Six Nations home fixtures. Ballot opens to students through the Sports Union each January.",
    ticketsUrl: "https://www.scottishrugby.org/tickets",
    x: 12, y: 31,
  },
  {
    id: "hibernian",
    name: "Hibernian FC home game",
    venue: "Easter Road Stadium",
    area: "Leith",
    day: "Sat",
    start: "15:00",
    category: "Pro sport",
    blurb: "SPFL Premiership. Atmospheric, walkable from Leith Walk halls. £15–25 student tickets.",
    ticketsUrl: "https://www.hibernianfc.co.uk/tickets",
    x: 75, y: 22,
  },
  {
    id: "hearts",
    name: "Heart of Midlothian FC home game",
    venue: "Tynecastle Park",
    area: "Gorgie",
    day: "Sat",
    start: "15:00",
    category: "Pro sport",
    blurb: "SPFL Premiership. Old-school stadium, fierce atmosphere. Bus 1 or 25 from Princes Street.",
    ticketsUrl: "https://www.heartsfc.co.uk/tickets",
    x: 16, y: 40,
  },
];

// Freshers' guide — first-week things every new student should do
export type FresherTip = {
  id: string;
  title: string;
  why: string;
  emoji: string;
};

export const FRESHER_TIPS: FresherTip[] = [
  {
    id: "arthurs-seat",
    title: "Climb Arthur's Seat",
    why: "Best view of the city. 45 min up an extinct volcano in the middle of town. Sunset is the move.",
    emoji: "⛰️",
  },
  {
    id: "bus-tour",
    title: "Open-top bus tour",
    why: "Tacky but actually the fastest way to orient yourself. Lothian Buses do an Edinburgh Tour for £18 hop-on hop-off.",
    emoji: "🚌",
  },
  {
    id: "greyfriars",
    title: "Greyfriars Bobby",
    why: "The famous wee terrier statue. Touch his nose for good luck on exams (locals will tell you not to — touch it anyway).",
    emoji: "🐕",
  },
  {
    id: "potterrow-bigcheese",
    title: "Big Cheese at Potterrow",
    why: "Saturday night, EUSA student union, cheese music and cheap pints. The Edinburgh rite of passage.",
    emoji: "🧀",
  },
  {
    id: "trash-monday",
    title: "Trash Mondays at The Hive",
    why: "£1 drinks, sticky floors, indie classics. Everyone goes once. Most go a lot more.",
    emoji: "🪩",
  },
  {
    id: "matric-card",
    title: "Pick up your matric card",
    why: "Required for the library, gym, exams and most student discounts. Sort it in the first week.",
    emoji: "🪪",
  },
  {
    id: "freshers-pubs",
    title: "Try a few student pubs",
    why: "Doctors (under-rated), Sandy Bell's (folk music), The Royal Oak (sing-alongs), Brass Monkey (sofas).",
    emoji: "🍺",
  },
  {
    id: "freshers-fair",
    title: "Go to the Freshers' Fair",
    why: "Bristo Square, week 1. Sign up to 5 societies you'll attend and 15 for the free stash.",
    emoji: "🎪",
  },
  {
    id: "calton-hill",
    title: "Calton Hill at golden hour",
    why: "Easier than Arthur's Seat. Iconic Edinburgh skyline shot with the National Monument behind you.",
    emoji: "🌇",
  },
  {
    id: "first-curry",
    title: "Mosque Kitchen lunch",
    why: "£6 for a curry and rice that'll keep you full till dinner. Eat outside, by the meadows.",
    emoji: "🍛",
  },
];
