export type Society = {
  id: string;
  name: string;
  category: "Sport" | "Academic" | "Cultural" | "Arts" | "Social" | "Volunteering";
  blurb: string;
  meets: { day: Weekday; start: string; end: string; venue: string }[];
  members: number;
};

export type Weekday = "Mon" | "Tue" | "Wed" | "Thu" | "Fri" | "Sat" | "Sun";
export const WEEKDAYS: Weekday[] = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

export const SOCIETIES: Society[] = [
  {
    id: "hillwalking",
    name: "Hillwalking Club",
    category: "Sport",
    blurb: "Weekend trips into the Pentlands, Cairngorms and beyond. Boots provided.",
    meets: [{ day: "Wed", start: "19:00", end: "20:30", venue: "Pleasance" }],
    members: 612,
  },
  {
    id: "film",
    name: "Film Society",
    category: "Arts",
    blurb: "Screenings every week at Teviot. From silent classics to new Scottish cinema.",
    meets: [{ day: "Thu", start: "20:00", end: "22:30", venue: "Teviot Debating Hall" }],
    members: 488,
  },
  {
    id: "football-mens",
    name: "Men's Football 3rds",
    category: "Sport",
    blurb: "Training at Peffermill. BUCS fixtures Wednesdays.",
    meets: [
      { day: "Tue", start: "18:00", end: "20:00", venue: "Peffermill" },
      { day: "Wed", start: "14:00", end: "17:00", venue: "Peffermill" },
    ],
    members: 84,
  },
  {
    id: "debates",
    name: "Edinburgh Union Debates",
    category: "Academic",
    blurb: "One of the oldest debating unions in the world. Open floor every Friday.",
    meets: [{ day: "Fri", start: "19:30", end: "22:00", venue: "Teviot Debating Hall" }],
    members: 320,
  },
  {
    id: "ceilidh",
    name: "Ceilidh Society",
    category: "Cultural",
    blurb: "Strip the Willow, Dashing White Sergeant. No experience needed.",
    meets: [{ day: "Mon", start: "19:30", end: "21:30", venue: "Pleasance Cabaret Bar" }],
    members: 540,
  },
  {
    id: "climbing",
    name: "Climbing Club",
    category: "Sport",
    blurb: "Bouldering at Alien Rock, outdoor trips to Glen Coe.",
    meets: [
      { day: "Mon", start: "18:00", end: "21:00", venue: "Alien Rock" },
      { day: "Thu", start: "18:00", end: "21:00", venue: "EICA Ratho" },
    ],
    members: 270,
  },
  {
    id: "lit",
    name: "Literary Society",
    category: "Academic",
    blurb: "Book club, guest readings, and the annual Old College anthology.",
    meets: [{ day: "Tue", start: "19:00", end: "20:30", venue: "50 George Square" }],
    members: 198,
  },
  {
    id: "bake",
    name: "Bake Soc",
    category: "Social",
    blurb: "Weekly bake-alongs and a yearly charity Great Edinburgh Bake Off.",
    meets: [{ day: "Sun", start: "14:00", end: "17:00", venue: "Chaplaincy Kitchen" }],
    members: 410,
  },
  {
    id: "fringe-vol",
    name: "Fringe Volunteers",
    category: "Volunteering",
    blurb: "Help run student venues across August. Free shows, free tee.",
    meets: [{ day: "Wed", start: "17:30", end: "19:00", venue: "Bristo Square" }],
    members: 156,
  },
  {
    id: "jazz",
    name: "Jazz Orchestra",
    category: "Arts",
    blurb: "Big band rehearsals; gigs at The Jazz Bar on the Cowgate.",
    meets: [{ day: "Thu", start: "18:30", end: "20:30", venue: "Reid Concert Hall" }],
    members: 62,
  },
];
