export type Contact = {
  id: string;
  name: string;
  number: string;
  description: string;
  category: "Mental health" | "Emergency" | "University" | "Transport" | "Sexual violence";
  urgent?: boolean;
  url?: string;
};

export const CONTACTS: Contact[] = [
  // Mental health
  {
    id: "nightline",
    name: "Edinburgh Nightline",
    number: "0131 557 4444",
    description: "Confidential listening service run by students, for students. Open 8pm–8am during term.",
    category: "Mental health",
  },
  {
    id: "samaritans",
    name: "Samaritans",
    number: "116 123",
    description: "Free, 24/7. You don't have to be suicidal to call — they're there for anything that's getting on top of you.",
    category: "Mental health",
    urgent: true,
  },
  {
    id: "student-counselling",
    name: "Student Counselling Service",
    number: "0131 650 4170",
    description: "Free 1:1 counselling for matriculated students. Self-refer online or call to book.",
    category: "University",
    url: "https://www.ed.ac.uk/student-counselling",
  },
  {
    id: "shout",
    name: "Shout 85258",
    number: "Text SHOUT to 85258",
    description: "Free 24/7 text support if you're in crisis and can't talk on the phone.",
    category: "Mental health",
  },

  // Emergency
  {
    id: "emergency",
    name: "Emergency Services",
    number: "999",
    description: "Police, ambulance, fire. Use 112 from a mobile if 999 won't connect.",
    category: "Emergency",
    urgent: true,
  },
  {
    id: "non-emergency-police",
    name: "Police Scotland (non-emergency)",
    number: "101",
    description: "For reporting incidents that aren't life-threatening — theft, harassment, anti-social behaviour.",
    category: "Emergency",
  },
  {
    id: "nhs-24",
    name: "NHS 24",
    number: "111",
    description: "Out-of-hours medical advice. Open when your GP is closed.",
    category: "Emergency",
  },

  // Sexual violence
  {
    id: "rape-crisis-scotland",
    name: "Rape Crisis Scotland",
    number: "08088 01 03 02",
    description: "Free helpline, 5pm–midnight every day. Confidential support for survivors of sexual violence of any kind, any time in the past.",
    category: "Sexual violence",
    url: "https://www.rapecrisisscotland.org.uk",
  },
  {
    id: "uoe-report-and-support",
    name: "University Report + Support",
    number: "Online form",
    description: "Report sexual misconduct, harassment, or hate crime to the University — anonymously if you prefer.",
    category: "Sexual violence",
    url: "https://reportandsupport.ed.ac.uk",
  },

  // Transport / getting home safe
  {
    id: "central-taxis",
    name: "Central Taxis",
    number: "0131 229 2468",
    description: "Edinburgh's biggest black-cab firm. Card payments in every cab.",
    category: "Transport",
  },
  {
    id: "city-cabs",
    name: "City Cabs",
    number: "0131 228 1211",
    description: "Reliable 24/7 taxi service. Book via app or phone.",
    category: "Transport",
  },
  {
    id: "uoe-safetaxi",
    name: "EUSA SafeTaxi scheme",
    number: "Show student card at Central Taxis",
    description: "Stuck without money to get home? Show your student card to a Central Taxi driver and pay EUSA back later.",
    category: "Transport",
    url: "https://www.eusa.ed.ac.uk/yourwellbeing/safetaxi/",
  },

  // University
  {
    id: "advice-place",
    name: "The Advice Place (EUSA)",
    number: "0131 650 9225",
    description: "Free, confidential advice on academic, financial, housing and welfare issues.",
    category: "University",
    url: "https://www.eusa.ed.ac.uk/advice",
  },
  {
    id: "uoe-security",
    name: "University Security Control",
    number: "0131 650 2257",
    description: "24/7. For incidents on University property — lost keys after hours, suspicious activity, urgent estates issues.",
    category: "University",
  },
];
