export type Deal = {
  id: string;
  name: string;
  category: "Food" | "Coffee" | "Groceries" | "Lifestyle" | "Books";
  area: "Old Town" | "Newington" | "Marchmont" | "Bristo Square" | "Leith" | "Tollcross";
  discount: string;
  details: string;
};

export const DEALS: Deal[] = [
  {
    id: "mosque-kitchen",
    name: "Mosque Kitchen",
    category: "Food",
    area: "Old Town",
    discount: "£1 off curry & rice",
    details: "Show app at the till. Mon–Fri before 3pm.",
  },
  {
    id: "kilimanjaro",
    name: "Kilimanjaro Coffee",
    category: "Coffee",
    area: "Newington",
    discount: "20% off all drinks",
    details: "All day, every day. Reusable cup gets you another 25p off.",
  },
  {
    id: "pep-co",
    name: "Pep & Co at Brunsfield",
    category: "Groceries",
    area: "Marchmont",
    discount: "10% student basket",
    details: "Minimum £10 spend. Valid weekdays.",
  },
  {
    id: "blackwells",
    name: "Blackwell's South Bridge",
    category: "Books",
    area: "Old Town",
    discount: "15% off course texts",
    details: "Bring reading list. Includes second-hand stock.",
  },
  {
    id: "city-cycles",
    name: "Edinburgh City Cycles",
    category: "Lifestyle",
    area: "Tollcross",
    discount: "Free first service",
    details: "Within 6 months of any bike purchase.",
  },
  {
    id: "leith-bakery",
    name: "Twelve Triangles",
    category: "Coffee",
    area: "Leith",
    discount: "Free pastry with any flat white",
    details: "Before 11am, weekdays only.",
  },
  {
    id: "potato-shop",
    name: "The Potato Shop",
    category: "Food",
    area: "Bristo Square",
    discount: "Loaded tattie for £4.50",
    details: "Usually £6. Quote the app.",
  },
  {
    id: "lidl-nicolson",
    name: "Lidl Nicolson Street",
    category: "Groceries",
    area: "Newington",
    discount: "Bonus 50p Lidl Plus coupon",
    details: "Link your Lidl Plus account in-store.",
  },
];
