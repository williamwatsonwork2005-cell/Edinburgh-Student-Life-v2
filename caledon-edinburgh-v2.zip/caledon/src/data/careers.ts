export type CareerEvent = {
  id: string;
  title: string;
  type: "Workshop" | "Fair" | "Talk" | "1-to-1";
  when: string;
  venue: string;
  blurb: string;
  bookingUrl?: string;
};

export const CAREER_EVENTS: CareerEvent[] = [
  {
    id: "cv-workshop",
    title: "CV Skills Workshop",
    type: "Workshop",
    when: "Wed 12 Nov · 14:00–15:30",
    venue: "Careers Service, 3rd floor, Main Library",
    blurb: "Hands-on session — bring a draft CV (paper or laptop). Career Consultants give 1-to-1 feedback in the second half.",
    bookingUrl: "https://www.ed.ac.uk/careers",
  },
  {
    id: "cover-letters",
    title: "Cover Letters That Get Read",
    type: "Workshop",
    when: "Mon 17 Nov · 13:00–14:00",
    venue: "Online (Zoom)",
    blurb: "How to tailor a cover letter for graduate schemes, internships and part-time roles. Includes example openings that work.",
    bookingUrl: "https://www.ed.ac.uk/careers",
  },
  {
    id: "autumn-careers-fair",
    title: "Autumn Careers Fair",
    type: "Fair",
    when: "Thu 23 Oct · 11:00–15:00",
    venue: "McEwan Hall",
    blurb: "100+ employers — banking, consulting, tech, charity, public sector. No need to dress formally; bring CVs.",
    bookingUrl: "https://www.ed.ac.uk/careers",
  },
  {
    id: "tech-fair",
    title: "Technology Careers Fair",
    type: "Fair",
    when: "Tue 28 Oct · 12:00–16:00",
    venue: "Informatics Forum",
    blurb: "FAANG, scale-ups, Edinburgh tech (Skyscanner, FanDuel, Travelnest). Open to all degrees, not just Informatics.",
    bookingUrl: "https://www.ed.ac.uk/careers",
  },
  {
    id: "consulting-talk",
    title: "Breaking into Consulting",
    type: "Talk",
    when: "Tue 4 Nov · 18:00–19:30",
    venue: "Old College, Moot Court",
    blurb: "MBB and Big Four consultants from Edinburgh offices on case interviews and applications. Free pizza.",
    bookingUrl: "https://www.ed.ac.uk/careers",
  },
  {
    id: "appointment",
    title: "1-to-1 Careers Appointment",
    type: "1-to-1",
    when: "30-min slots, Mon–Fri",
    venue: "Careers Service or online",
    blurb: "Book a slot with a Career Consultant — CV review, course choices, postgraduate study, application strategy.",
    bookingUrl: "https://www.ed.ac.uk/careers",
  },
  {
    id: "law-fair",
    title: "Law Fair",
    type: "Fair",
    when: "Wed 5 Nov · 13:00–17:00",
    venue: "Playfair Library Hall, Old College",
    blurb: "Magic Circle, Silver Circle, Scottish firms and US firms with Edinburgh trainee schemes. Open to all years.",
    bookingUrl: "https://www.ed.ac.uk/careers",
  },
  {
    id: "linkedin-headshots",
    title: "Free LinkedIn Headshots",
    type: "1-to-1",
    when: "Thu 30 Oct · 10:00–16:00",
    venue: "Careers Service",
    blurb: "Drop-in photo session. Professional photographer, plain backdrop. 10 minutes, walk out with a usable headshot.",
    bookingUrl: "https://www.ed.ac.uk/careers",
  },
];
