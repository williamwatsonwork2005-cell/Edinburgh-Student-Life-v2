export type Audience = "halls" | "private";

export type Listing = {
  id: string;
  agent: string;
  area: string;
  type: "Studio" | "1 bed" | "2 bed" | "3 bed" | "4 bed" | "5 bed" | "Halls";
  audience: Audience;
  pcm: number;
  walkToCentral: number; // minutes
  perks: string[];
  available: string;
};

export const LISTINGS: Listing[] = [
  // Halls — for prospective + year 1
  {
    id: "pollock",
    agent: "University of Edinburgh",
    area: "Pollock Halls",
    type: "Halls",
    audience: "halls",
    pcm: 880,
    walkToCentral: 18,
    perks: ["Catered option", "Single ensuite", "First-year priority"],
    available: "Sep 2026",
  },
  {
    id: "kincaids",
    agent: "University of Edinburgh",
    area: "Kincaid's Court",
    type: "Halls",
    audience: "halls",
    pcm: 920,
    walkToCentral: 5,
    perks: ["Self-catered", "Shared kitchen", "5 min to Old College"],
    available: "Sep 2026",
  },
  {
    id: "salisbury",
    agent: "University of Edinburgh",
    area: "Salisbury Court",
    type: "Halls",
    audience: "halls",
    pcm: 810,
    walkToCentral: 12,
    perks: ["Budget self-catered", "Bills included", "Wifi included"],
    available: "Sep 2026",
  },
  {
    id: "murano",
    agent: "Unite Students",
    area: "Murano Place (PBSA)",
    type: "Halls",
    audience: "halls",
    pcm: 990,
    walkToCentral: 20,
    perks: ["Ensuite", "Gym", "Bills + wifi"],
    available: "Sep 2026",
  },
  // Private flats — year 2+
  {
    id: "marchmont-3",
    agent: "Cullen Property",
    area: "Marchmont",
    type: "3 bed",
    audience: "private",
    pcm: 1850,
    walkToCentral: 12,
    perks: ["No admin fee for app users", "Bills included", "Furnished"],
    available: "Sep 2026",
  },
  {
    id: "newington-2",
    agent: "Grant Management",
    area: "Newington",
    type: "2 bed",
    audience: "private",
    pcm: 1450,
    walkToCentral: 8,
    perks: ["EPC B", "Washer/dryer", "Bike storage"],
    available: "Aug 2026",
  },
  {
    id: "tollcross-studio",
    agent: "Edinburgh Lets",
    area: "Tollcross",
    type: "Studio",
    audience: "private",
    pcm: 925,
    walkToCentral: 15,
    perks: ["All bills included", "Council tax exempt"],
    available: "Now",
  },
  {
    id: "bruntsfield-4",
    agent: "Umega",
    area: "Bruntsfield",
    type: "4 bed",
    audience: "private",
    pcm: 2400,
    walkToCentral: 18,
    perks: ["HMO licensed", "Garden", "Dishwasher"],
    available: "Sep 2026",
  },
  {
    id: "leith-1",
    agent: "Murray & Currie",
    area: "Leith Walk",
    type: "1 bed",
    audience: "private",
    pcm: 1100,
    walkToCentral: 25,
    perks: ["Tram to Old College", "Modern build"],
    available: "Jul 2026",
  },
  {
    id: "stockbridge-5",
    agent: "Cullen Property",
    area: "Stockbridge",
    type: "5 bed",
    audience: "private",
    pcm: 3100,
    walkToCentral: 22,
    perks: ["Period townhouse", "Two bathrooms"],
    available: "Sep 2026",
  },
];
