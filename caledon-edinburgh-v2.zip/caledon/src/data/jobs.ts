export type Job = {
  id: string;
  title: string;
  employer: string;
  area: string;
  pay: string;
  hours: string;
  category: "Hospitality" | "Retail" | "Tutoring" | "Campus" | "Events" | "Office";
  blurb: string;
  postedAgo: string;
  externalUrl?: string;
};

export const JOBS: Job[] = [
  {
    id: "barista-soderberg",
    title: "Weekend Barista",
    employer: "Söderberg",
    area: "Quartermile",
    pay: "£12.50/hr + tips",
    hours: "Sat–Sun, 8am–3pm",
    category: "Hospitality",
    blurb: "Busy Swedish bakery a 2-min walk from the Main Library. Training given.",
    postedAgo: "2 days ago",
    externalUrl: "https://soderberg.uk/careers",
  },
  {
    id: "tutor-maths",
    title: "Maths Tutor (S4–S6)",
    employer: "MyTutor",
    area: "Remote",
    pay: "£18–28/hr",
    hours: "Flexible, 2–8 hrs/week",
    category: "Tutoring",
    blurb: "Set your own schedule. Higher and Advanced Higher level. Apply with A-level or equivalent results.",
    postedAgo: "1 week ago",
    externalUrl: "https://www.mytutor.co.uk/jobs/online-tutor",
  },
  {
    id: "bartender-teviot",
    title: "Bar Staff",
    employer: "Teviot Row House (EUSA)",
    area: "Bristo Square",
    pay: "£11.65/hr",
    hours: "Evenings, 12 hrs/week",
    category: "Campus",
    blurb: "Student-run union bar. Pays Edinburgh Living Wage and works around your timetable.",
    postedAgo: "3 days ago",
    externalUrl: "https://www.eusa.ed.ac.uk/jobs/",
  },
  {
    id: "retail-john-lewis",
    title: "Sales Assistant",
    employer: "John Lewis & Partners",
    area: "St James Quarter",
    pay: "£12.00/hr",
    hours: "16 hrs/week, weekend cover",
    category: "Retail",
    blurb: "Permanent part-time. Partner discount on top — 12% off most departments.",
    postedAgo: "5 days ago",
    externalUrl: "https://www.jlpjobs.com",
  },
  {
    id: "library-assistant",
    title: "Library Assistant (Student)",
    employer: "Information Services, UoE",
    area: "Main Library",
    pay: "£12.34/hr",
    hours: "Evenings + weekends, ~10 hrs/week",
    category: "Campus",
    blurb: "Shelving, customer enquiries, opening/closing duties. Quiet shifts good for getting reading done.",
    postedAgo: "1 week ago",
    externalUrl: "https://www.ed.ac.uk/human-resources/jobs",
  },
  {
    id: "events-fringe",
    title: "Fringe Box Office (Aug)",
    employer: "Edinburgh Festival Fringe",
    area: "Various venues",
    pay: "£12.60/hr + free shows",
    hours: "Aug only, full or part-time",
    category: "Events",
    blurb: "Seasonal August work — sell tickets, scan punters in, occasionally cover the bar. Free Fringe pass.",
    postedAgo: "Posted seasonally",
    externalUrl: "https://www.edfringe.com/take-part/jobs",
  },
  {
    id: "waiter-dishoom",
    title: "Front of House",
    employer: "Dishoom",
    area: "St Andrew Square",
    pay: "£12.00/hr + tronc",
    hours: "Evenings, 16–25 hrs/week",
    category: "Hospitality",
    blurb: "Bombay-style cafe. Tronc averages £4–5/hr on top. Free shift meals.",
    postedAgo: "4 days ago",
    externalUrl: "https://www.dishoom.com/careers",
  },
  {
    id: "office-admin",
    title: "Office Admin Assistant",
    employer: "Scottish Mountaineering Press",
    area: "Newington",
    pay: "£11.80/hr",
    hours: "15 hrs/week",
    category: "Office",
    blurb: "Quiet office, flexible hours. Good for postgrads. Light admin and customer support.",
    postedAgo: "1 week ago",
    externalUrl: "https://www.smc.org.uk/about/jobs",
  },
];
