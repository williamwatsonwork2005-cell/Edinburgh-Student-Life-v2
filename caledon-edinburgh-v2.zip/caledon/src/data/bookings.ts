export type Busyness = "Quiet" | "Medium" | "Busy";

export type Bookable = {
  id: string;
  name: string;
  type: "Study room" | "Sports pitch" | "Studio" | "Gym class";
  building: string;
  bookingUrl: string;
  note: string;
  hours?: string;
  busyByDay?: Partial<Record<"Mon" | "Tue" | "Wed" | "Thu" | "Fri" | "Sat" | "Sun", Busyness>>;
  busyNote?: string;
};

export const BOOKABLES: Bookable[] = [
  {
    id: "main-lib",
    name: "Main Library study rooms",
    type: "Study room",
    building: "George Square",
    bookingUrl: "https://www.ed.ac.uk/information-services/library-museum-gallery",
    note: "Bookable in 1-hour slots, up to 7 days ahead.",
    hours: "24/7",
    busyByDay: { Mon: "Medium", Tue: "Busy", Wed: "Busy", Thu: "Busy", Fri: "Medium", Sat: "Medium", Sun: "Busy" },
    busyNote: "Heaving 11am–4pm during semester. Best after 8pm or before 10am.",
  },
  {
    id: "noble-room",
    name: "Noble Room group study",
    type: "Study room",
    building: "Main Library, L3",
    bookingUrl: "https://www.ed.ac.uk/information-services/library-museum-gallery",
    note: "Up to 8 people. Whiteboard and screen.",
    hours: "24/7",
    busyByDay: { Mon: "Medium", Tue: "Busy", Wed: "Busy", Thu: "Busy", Fri: "Medium", Sat: "Quiet", Sun: "Medium" },
    busyNote: "Book a week ahead in deadline season.",
  },
  {
    id: "peffermill",
    name: "Peffermill 3G football pitch",
    type: "Sports pitch",
    building: "Peffermill Playing Fields",
    bookingUrl: "https://www.ed.ac.uk/sport-exercise",
    note: "Hourly hire. Bring your own ball.",
    hours: "Daily 8:00–22:00",
    busyByDay: { Wed: "Busy", Sat: "Busy", Sun: "Medium" },
    busyNote: "Wednesday afternoons taken by BUCS fixtures. Easiest mid-week evenings.",
  },
  {
    id: "pleasance-court",
    name: "Pleasance squash court",
    type: "Sports pitch",
    building: "Pleasance",
    bookingUrl: "https://www.ed.ac.uk/sport-exercise",
    note: "45-min slots. Racquet hire £1.",
    hours: "Mon–Fri 6:00–22:00 · Sat–Sun 9:00–20:00",
    busyByDay: { Mon: "Busy", Tue: "Medium", Wed: "Busy", Thu: "Medium", Fri: "Medium", Sat: "Quiet", Sun: "Quiet" },
    busyNote: "6–8pm courts go first. Mornings always free.",
  },
  {
    id: "alison-house",
    name: "Alison House practice room",
    type: "Studio",
    building: "Reid School of Music",
    bookingUrl: "https://www.ed.ac.uk/music",
    note: "Music students get priority booking.",
    hours: "Mon–Fri 9:00–22:00 · Sat–Sun 10:00–18:00",
    busyByDay: { Mon: "Medium", Tue: "Busy", Wed: "Medium", Thu: "Busy", Fri: "Medium" },
    busyNote: "Booked up around recital deadlines (late Nov, late Mar).",
  },
  {
    id: "spin",
    name: "Centre Spin class",
    type: "Gym class",
    building: "Pleasance",
    bookingUrl: "https://www.ed.ac.uk/sport-exercise",
    note: "Free with sports membership.",
    hours: "Mon–Fri 6:00–22:00 · Sat–Sun 9:00–20:00",
    busyByDay: { Mon: "Busy", Tue: "Busy", Wed: "Medium", Thu: "Busy", Fri: "Medium" },
    busyNote: "6pm classes sell out same day. Book the 48hr window opens.",
  },
];

export type Membership = {
  id: string;
  name: string;
  price: string;
  duration: string;
  blurb: string;
  url: string;
};

export const MEMBERSHIPS: Membership[] = [
  {
    id: "pleasance-annual",
    name: "Pleasance — Full Year",
    price: "£185",
    duration: "Sept–Aug",
    blurb: "Unlimited gym + classes + pool. Best value if you'll go more than 30 times.",
    url: "https://www.ed.ac.uk/sport-exercise/memberships",
  },
  {
    id: "pleasance-semester",
    name: "Pleasance — Single Semester",
    price: "£105",
    duration: "One semester",
    blurb: "Same access as annual but for one semester. Good for a trial run.",
    url: "https://www.ed.ac.uk/sport-exercise/memberships",
  },
  {
    id: "sports-union",
    name: "Sports Union Membership",
    price: "£45",
    duration: "Sept–Aug",
    blurb: "Required to join any club doing BUCS competitions. Separate from the Pleasance gym pass.",
    url: "https://www.eusu.ed.ac.uk/about/sports-union/",
  },
  {
    id: "intramural",
    name: "Intramural Sport",
    price: "£15 per team",
    duration: "Per league",
    blurb: "Casual leagues — football, netball, basketball, badminton. Sign up a team with your flat or course-mates.",
    url: "https://www.ed.ac.uk/sport-exercise/intra-mural",
  },
];
