import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Briefcase, ExternalLink, Coffee, Store, GraduationCap, Calendar, Building2, BookOpen, Search } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { JOBS, type Job } from "@/data/jobs";

export const Route = createFileRoute("/work")({
  head: () => ({
    meta: [
      { title: "Work — Caledon" },
      { name: "description", content: "Part-time jobs around Edinburgh for students — bar work, retail, tutoring, campus jobs and seasonal Fringe roles." },
    ],
  }),
  component: WorkPage,
});

const CATS: ("All" | Job["category"])[] = ["All", "Hospitality", "Retail", "Tutoring", "Campus", "Events", "Office"];

const CAT_ICON: Record<Job["category"], React.ComponentType<{ className?: string }>> = {
  Hospitality: Coffee,
  Retail: Store,
  Tutoring: BookOpen,
  Campus: GraduationCap,
  Events: Calendar,
  Office: Building2,
};

function WorkPage() {
  const [cat, setCat] = useState<(typeof CATS)[number]>("All");
  const [q, setQ] = useState("");

  const filtered = JOBS.filter(
    (j) =>
      (cat === "All" || j.category === cat) &&
      (q === "" ||
        j.title.toLowerCase().includes(q.toLowerCase()) ||
        j.employer.toLowerCase().includes(q.toLowerCase()) ||
        j.area.toLowerCase().includes(q.toLowerCase())),
  );

  return (
    <div className="p-6 lg:p-10 max-w-7xl mx-auto space-y-8">
      <header className="space-y-2">
        <Badge variant="secondary" className="rounded-full">
          <Briefcase className="h-3 w-3 mr-1" /> Earn while you study
        </Badge>
        <h1 className="text-4xl md:text-5xl font-display">Work</h1>
        <p className="text-muted-foreground max-w-2xl">
          Part-time jobs around Edinburgh — curated for students. A couple of nights a week, weekend shifts,
          term-time only. New listings added weekly.
        </p>
      </header>

      <Card className="bg-secondary/40">
        <CardContent className="pt-6 flex flex-wrap items-center gap-3">
          <div className="flex-1 min-w-[240px] flex items-center gap-2">
            <Search className="h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by role, employer or area…"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              className="bg-card"
            />
          </div>
        </CardContent>
      </Card>

      <div className="flex flex-wrap gap-2">
        {CATS.map((c) => (
          <button
            key={c}
            onClick={() => setCat(c)}
            className={`text-xs px-3 py-1.5 rounded-full border transition ${
              cat === c
                ? "bg-primary text-primary-foreground border-primary"
                : "bg-card text-muted-foreground border-border hover:text-foreground"
            }`}
          >
            {c}
          </button>
        ))}
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {filtered.map((j) => {
          const Icon = CAT_ICON[j.category];
          return (
            <Card key={j.id}>
              <CardHeader className="pb-2">
                <div className="flex items-start justify-between gap-2">
                  <CardTitle className="font-display text-xl leading-tight">{j.title}</CardTitle>
                  <Badge variant="outline" className="shrink-0">
                    <Icon className="h-3 w-3 mr-1" />
                    {j.category}
                  </Badge>
                </div>
                <div className="text-xs text-muted-foreground">
                  {j.employer} · {j.area}
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex flex-wrap gap-1.5 text-xs">
                  <Badge variant="secondary">{j.pay}</Badge>
                  <Badge variant="secondary">{j.hours}</Badge>
                </div>
                <p className="text-sm text-muted-foreground">{j.blurb}</p>
                <div className="flex items-center justify-between pt-1">
                  <div className="text-xs text-muted-foreground">{j.postedAgo}</div>
                  {j.externalUrl && (
                    <Button asChild size="sm" variant="default">
                      <a href={j.externalUrl} target="_blank" rel="noopener noreferrer">
                        Apply <ExternalLink className="h-3 w-3 ml-1.5" />
                      </a>
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          );
        })}
        {filtered.length === 0 && (
          <p className="text-sm text-muted-foreground">
            No matches. Try a different search or clear the category filter.
          </p>
        )}
      </div>

      <Card className="bg-muted/40">
        <CardContent className="pt-6 text-sm text-muted-foreground">
          <p className="mb-1">
            <strong className="text-foreground">Tip:</strong> EUSA-run venues (Teviot, Potterrow, Pleasance bars) pay the
            Edinburgh Living Wage and almost always flex around your timetable.
          </p>
          <p>
            For graduate roles, internships and Spring Weeks — head to the{" "}
            <a href="/careers" className="underline text-foreground">
              Careers
            </a>{" "}
            page.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
