import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { ExternalLink, MapPin, Ticket, Sparkles, Search } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { EVENTS, FRESHER_TIPS, type EventCategory } from "@/data/events";
import type { Weekday } from "@/data/societies";

export const Route = createFileRoute("/events")({
  head: () => ({
    meta: [
      { title: "Events — Caledon" },
      { name: "description", content: "Where Edinburgh students go and when — nightlife, gigs, varsity matches, pro sport, comedy and culture, with Fixr tickets." },
    ],
  }),
  component: EventsPage,
});

const CATS: ("All" | EventCategory)[] = [
  "All",
  "Nightlife",
  "Live music",
  "Comedy",
  "Society",
  "Sport",
  "Varsity",
  "Pro sport",
  "Culture",
];
const DAYS: ("All week" | Weekday)[] = ["All week", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

const CAT_COLOR: Record<EventCategory, string> = {
  Nightlife: "oklch(0.55 0.16 305)", // thistle purple
  "Live music": "oklch(0.62 0.18 30)",
  Comedy: "oklch(0.74 0.14 80)", // gold
  Society: "oklch(0.55 0.13 220)",
  Sport: "oklch(0.5 0.13 145)",
  Varsity: "oklch(0.55 0.21 25)",
  "Pro sport": "oklch(0.4 0.14 250)",
  Culture: "oklch(0.6 0.14 340)",
};

function EventsPage() {
  const [cat, setCat] = useState<(typeof CATS)[number]>("All");
  const [day, setDay] = useState<(typeof DAYS)[number]>("All week");
  const [activeId, setActiveId] = useState<string | null>(null);
  const [fixrQuery, setFixrQuery] = useState("");

  const filtered = EVENTS.filter(
    (e) => (cat === "All" || e.category === cat) && (day === "All week" || e.day === day),
  );

  const fixrSearchUrl = fixrQuery.trim()
    ? `https://fixr.co/search?query=${encodeURIComponent(fixrQuery + " edinburgh")}`
    : "https://fixr.co/search?query=edinburgh";

  return (
    <div className="p-6 lg:p-10 max-w-7xl mx-auto space-y-8">
      <header className="space-y-2">
        <Badge variant="secondary" className="rounded-full">
          Where students go
        </Badge>
        <h1 className="text-4xl md:text-5xl font-display">Events map</h1>
        <p className="text-muted-foreground max-w-2xl">
          A weekly cheat-sheet — nightlife, varsity matches, pro sport at Murrayfield, comedy at the
          Stand, classical at the Usher Hall. Tap a pin for details and ticket links.
        </p>
      </header>

      {/* Freshers' guide — only the most prominent first-week things */}
      <section className="space-y-3">
        <div className="flex items-center gap-2">
          <Sparkles className="h-5 w-5 text-accent" />
          <h2 className="font-display text-2xl">Freshers' guide — first week</h2>
        </div>
        <p className="text-sm text-muted-foreground -mt-1">
          New to Edinburgh? Hit these before lectures swallow your evenings.
        </p>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {FRESHER_TIPS.map((t) => (
            <Card key={t.id} className="bg-gradient-to-br from-secondary/40 to-card">
              <CardContent className="pt-5 space-y-1.5">
                <div className="text-2xl leading-none" aria-hidden>
                  {t.emoji}
                </div>
                <div className="font-display text-lg leading-tight">{t.title}</div>
                <p className="text-xs text-muted-foreground">{t.why}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Fixr search */}
      <Card className="bg-secondary/40">
        <CardContent className="pt-6 flex flex-wrap items-center gap-3 justify-between">
          <div className="flex-1 min-w-[240px] flex items-center gap-2">
            <Search className="h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search Fixr — DJ name, club, event…"
              value={fixrQuery}
              onChange={(e) => setFixrQuery(e.target.value)}
              className="bg-card"
            />
          </div>
          <Button asChild variant="default">
            <a href={fixrSearchUrl} target="_blank" rel="noopener noreferrer">
              <Ticket className="h-3.5 w-3.5 mr-1.5" /> Search Fixr
            </a>
          </Button>
        </CardContent>
      </Card>

      <div className="space-y-2">
        <div className="flex flex-wrap gap-1.5">
          {CATS.map((c) => (
            <button
              key={c}
              onClick={() => setCat(c)}
              className={`text-xs px-3 py-1.5 rounded-full border transition ${
                cat === c
                  ? "bg-primary text-primary-foreground border-primary"
                  : "bg-card text-muted-foreground border-border hover:text-foreground"
              }`}
            >
              {c}
            </button>
          ))}
        </div>
        <div className="flex flex-wrap gap-1.5">
          {DAYS.map((d) => (
            <button
              key={d}
              onClick={() => setDay(d)}
              className={`text-xs px-3 py-1.5 rounded-full border transition ${
                day === d
                  ? "bg-accent text-accent-foreground border-accent"
                  : "bg-card text-muted-foreground border-border hover:text-foreground"
              }`}
            >
              {d}
            </button>
          ))}
        </div>
      </div>

      {/* Stylised map */}
      <Card className="overflow-hidden">
        <div className="relative bg-gradient-to-br from-stone via-secondary to-gold/30 aspect-[16/9]">
          <svg
            viewBox="0 0 100 60"
            className="absolute inset-0 w-full h-full"
            preserveAspectRatio="none"
          >
            <path d="M0,15 Q30,10 60,18 T100,22" stroke="hsl(200 30% 70% / 0.5)" strokeWidth="0.4" fill="none" />
            <path d="M40,42 L70,52" stroke="hsl(30 30% 40% / 0.4)" strokeWidth="0.5" fill="none" />
            <path d="M30,32 L70,35" stroke="hsl(30 30% 40% / 0.4)" strokeWidth="0.5" fill="none" />
            <text x="2" y="6" className="fill-current text-foreground/40" fontSize="2.2">
              Edinburgh — central
            </text>
            <text x="10" y="36" className="fill-current text-foreground/50" fontSize="1.8">
              Murrayfield
            </text>
            <text x="42" y="30" className="fill-current text-foreground/50" fontSize="1.8">
              George St
            </text>
            <text x="42" y="50" className="fill-current text-foreground/50" fontSize="1.8">
              Old Town
            </text>
            <text x="70" y="58" className="fill-current text-foreground/50" fontSize="1.8">
              Holyrood
            </text>
            <text x="73" y="20" className="fill-current text-foreground/50" fontSize="1.8">
              Leith
            </text>
          </svg>
          {filtered.map((e) => {
            const active = activeId === e.id;
            return (
              <button
                key={e.id}
                onClick={() => setActiveId(active ? null : e.id)}
                className="absolute -translate-x-1/2 -translate-y-full group"
                style={{ left: `${e.x}%`, top: `${e.y}%` }}
                aria-label={e.name}
              >
                <div
                  className={`flex items-center justify-center rounded-full border-2 border-background shadow-md transition ${
                    active ? "h-7 w-7 scale-110" : "h-5 w-5 hover:scale-110"
                  }`}
                  style={{ backgroundColor: CAT_COLOR[e.category] }}
                >
                  <MapPin className="h-3 w-3 text-white" />
                </div>
                {active && (
                  <div className="absolute left-1/2 top-full mt-1 -translate-x-1/2 z-10 w-56 text-left">
                    <Card className="p-3 space-y-1 shadow-lg">
                      <div className="text-xs text-muted-foreground">
                        {e.day} · {e.start}
                      </div>
                      <div className="font-display text-base leading-tight">{e.name}</div>
                      <div className="text-xs text-muted-foreground">
                        {e.venue} · {e.area}
                      </div>
                      {(e.fixrUrl || e.ticketsUrl) && (
                        <Button asChild size="sm" variant="default" className="w-full mt-1 h-7 text-xs">
                          <a
                            href={e.fixrUrl || e.ticketsUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                          >
                            <Ticket className="h-3 w-3 mr-1" />
                            {e.fixrUrl ? "Tickets on Fixr" : "Tickets"}
                          </a>
                        </Button>
                      )}
                    </Card>
                  </div>
                )}
              </button>
            );
          })}
        </div>
      </Card>

      {/* List */}
      <div className="grid gap-3 md:grid-cols-2">
        {filtered.map((e) => (
          <Card key={e.id} className="overflow-hidden">
            <CardContent className="pt-5 space-y-2">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="text-xs text-muted-foreground">
                    {e.day} · {e.start}
                  </div>
                  <div className="font-display text-xl leading-tight">{e.name}</div>
                  <div className="text-xs text-muted-foreground">
                    {e.venue} · {e.area}
                  </div>
                </div>
                <Badge
                  variant="outline"
                  className="shrink-0"
                  style={{ borderColor: CAT_COLOR[e.category], color: CAT_COLOR[e.category] }}
                >
                  {e.category}
                </Badge>
              </div>
              <p className="text-sm text-muted-foreground">{e.blurb}</p>
              {(e.fixrUrl || e.ticketsUrl) && (
                <Button asChild size="sm" variant="secondary">
                  <a href={e.fixrUrl || e.ticketsUrl} target="_blank" rel="noopener noreferrer">
                    <Ticket className="h-3.5 w-3.5 mr-1.5" />
                    {e.fixrUrl ? "Tickets on Fixr" : "Tickets"}
                    <ExternalLink className="h-3 w-3 ml-1.5" />
                  </a>
                </Button>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
