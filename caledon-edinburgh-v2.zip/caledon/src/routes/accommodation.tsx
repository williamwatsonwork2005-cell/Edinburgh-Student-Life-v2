import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Home as HomeIcon, MapPin, GraduationCap, Heart, Star, HeartHandshake } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { LISTINGS, type Audience } from "@/data/accommodation";
import { useProfile, STAGE_LABEL } from "@/lib/profile";
import { useShortlist } from "@/lib/shortlist";

export const Route = createFileRoute("/accommodation")({
  head: () => ({
    meta: [
      { title: "Accommodation — Caledon" },
      { name: "description", content: "Halls of residence and partner letting agents. Shortlist, rate and find flatmates — all in one place." },
    ],
  }),
  component: AccommodationPage,
});

const AUDIENCE_LABEL: Record<Audience, string> = {
  halls: "Halls of residence",
  private: "Private flats",
};

type View = "browse" | "shortlist";

function AccommodationPage() {
  const { profile } = useProfile();
  const { likes, ratings, toggleLike, setRating, overall } = useShortlist();
  const defaultAudience: Audience =
    profile?.stage === "prospective" || profile?.stage === "year1" ? "halls" : "private";
  const [audience, setAudience] = useState<Audience>(defaultAudience);
  const [maxRent, setMaxRent] = useState(3500);
  const [view, setView] = useState<View>("browse");

  const browseList = LISTINGS.filter((l) => l.audience === audience && l.pcm <= maxRent).sort(
    (a, b) => a.pcm - b.pcm,
  );
  const shortlistList = LISTINGS.filter((l) => likes.includes(l.id)).sort((a, b) => a.pcm - b.pcm);
  const list = view === "browse" ? browseList : shortlistList;

  return (
    <div className="p-6 lg:p-10 max-w-7xl mx-auto space-y-8">
      <header className="space-y-2">
        <Badge variant="secondary" className="rounded-full">
          Partner agents + University halls
        </Badge>
        <h1 className="text-4xl md:text-5xl font-display">Accommodation</h1>
        <p className="text-muted-foreground max-w-2xl">
          {audience === "halls"
            ? "Catered and self-catered halls for first-years and prospective students."
            : "Curated student-ready flats from Edinburgh letting agents who've waived admin fees for Caledon users."}
        </p>
      </header>

      {profile && (
        <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
          <GraduationCap className="h-3.5 w-3.5" />
          You're set as: <span className="font-medium text-foreground">{STAGE_LABEL[profile.stage]}</span>
        </div>
      )}

      {/* Flatmate finder CTA */}
      <Card className="border-accent/40 bg-accent/5">
        <CardContent className="pt-6 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <HeartHandshake className="h-7 w-7 text-accent shrink-0" />
            <div>
              <div className="font-display text-lg">Looking for flatmates?</div>
              <div className="text-sm text-muted-foreground">
                Take the survey to be matched with compatible UoE students. Safer than Marketplace.
              </div>
            </div>
          </div>
          <Button asChild>
            <Link to="/flatmates">Open Flatmate finder</Link>
          </Button>
        </CardContent>
      </Card>

      {/* View + audience toggles */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex gap-2">
          <Button
            size="sm"
            variant={view === "browse" ? "default" : "outline"}
            onClick={() => setView("browse")}
          >
            Browse
          </Button>
          <Button
            size="sm"
            variant={view === "shortlist" ? "default" : "outline"}
            onClick={() => setView("shortlist")}
          >
            <Heart className="h-3.5 w-3.5 mr-1.5" /> Shortlist ({likes.length})
          </Button>
        </div>
        {view === "browse" && (
          <div className="flex flex-wrap gap-2">
            {(Object.keys(AUDIENCE_LABEL) as Audience[]).map((a) => (
              <Button
                key={a}
                variant={audience === a ? "default" : "outline"}
                size="sm"
                onClick={() => setAudience(a)}
                className="rounded-full"
              >
                {AUDIENCE_LABEL[a]}
              </Button>
            ))}
          </div>
        )}
      </div>

      {view === "browse" && (
        <Card className="bg-secondary/50">
          <CardContent className="pt-6 space-y-3">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">
                Max {audience === "halls" ? "weekly equivalent" : "rent"} (pcm)
              </span>
              <span className="font-semibold">£{maxRent.toLocaleString()}</span>
            </div>
            <Slider
              value={[maxRent]}
              min={500}
              max={3500}
              step={50}
              onValueChange={(v) => setMaxRent(v[0])}
            />
          </CardContent>
        </Card>
      )}

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {list.map((l) => {
          const liked = likes.includes(l.id);
          const r = ratings[l.id];
          const avg = overall(l.id);
          return (
            <Card key={l.id} className={`overflow-hidden ${liked ? "border-accent" : ""}`}>
              <div className="h-24 bg-gradient-to-br from-stone via-secondary to-gold/40 flex items-center justify-center relative">
                <HomeIcon className="h-8 w-8 text-primary/40" />
                <button
                  onClick={() => toggleLike(l.id)}
                  aria-label={liked ? "Remove from shortlist" : "Add to shortlist"}
                  className="absolute top-2 right-2 h-8 w-8 rounded-full bg-background/90 backdrop-blur flex items-center justify-center shadow-sm transition hover:scale-110"
                >
                  <Heart
                    className={`h-4 w-4 ${liked ? "fill-accent text-accent" : "text-muted-foreground"}`}
                  />
                </button>
              </div>
              <CardHeader className="pb-2">
                <div className="flex items-start justify-between gap-2">
                  <CardTitle className="font-display text-xl leading-tight">
                    {l.type} · {l.area}
                  </CardTitle>
                  <Badge variant="outline">{l.available}</Badge>
                </div>
                <div className="text-xs text-muted-foreground">{l.agent}</div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-baseline justify-between">
                  <div className="text-2xl font-display text-foreground">
                    £{l.pcm.toLocaleString()}
                    <span className="text-sm text-muted-foreground"> pcm</span>
                  </div>
                  <div className="text-xs text-muted-foreground flex items-center gap-1">
                    <MapPin className="h-3 w-3" /> {l.walkToCentral} min to Central
                  </div>
                </div>
                <div className="flex flex-wrap gap-1">
                  {l.perks.map((p) => (
                    <Badge key={p} variant="secondary" className="text-[11px]">
                      {p}
                    </Badge>
                  ))}
                </div>

                {/* 1-5 rating axes */}
                <div className="space-y-1.5 pt-2 border-t border-border/50">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-muted-foreground">Your ratings</span>
                    {avg > 0 && (
                      <span className="text-foreground font-medium">
                        Overall {avg.toFixed(1)}/5
                      </span>
                    )}
                  </div>
                  <RatingRow label="Location" value={r?.location ?? 0} onChange={(v) => setRating(l.id, "location", v)} />
                  <RatingRow label="Quality" value={r?.quality ?? 0} onChange={(v) => setRating(l.id, "quality", v)} />
                  <RatingRow label="Price" value={r?.price ?? 0} onChange={(v) => setRating(l.id, "price", v)} />
                </div>
              </CardContent>
            </Card>
          );
        })}
        {list.length === 0 && view === "browse" && (
          <p className="text-sm text-muted-foreground">Nothing within that budget — try raising the slider.</p>
        )}
        {list.length === 0 && view === "shortlist" && (
          <p className="text-sm text-muted-foreground">
            No shortlist yet. Tap the heart icon on any listing to save it here.
          </p>
        )}
      </div>
    </div>
  );
}

function RatingRow({
  label,
  value,
  onChange,
}: {
  label: string;
  value: number;
  onChange: (v: number) => void;
}) {
  return (
    <div className="flex items-center justify-between gap-2 text-[11px]">
      <span className="text-muted-foreground w-14">{label}</span>
      <div className="flex gap-0.5">
        {[1, 2, 3, 4, 5].map((n) => (
          <button
            key={n}
            onClick={() => onChange(n === value ? 0 : n)}
            aria-label={`${label} ${n}`}
            className="p-0.5 transition hover:scale-110"
          >
            <Star
              className={`h-3.5 w-3.5 ${
                n <= value ? "fill-accent text-accent" : "text-muted-foreground/30"
              }`}
            />
          </button>
        ))}
      </div>
    </div>
  );
}
