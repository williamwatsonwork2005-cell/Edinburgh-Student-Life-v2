import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import {
  Dumbbell,
  BookOpen,
  Music,
  Trophy,
  ExternalLink,
  LayoutGrid,
  Clock,
  Activity,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { BOOKABLES, MEMBERSHIPS, type Bookable, type Busyness } from "@/data/bookings";
import { WEEKDAYS, type Weekday } from "@/data/societies";

export const Route = createFileRoute("/bookings")({
  head: () => ({
    meta: [
      { title: "Bookings — Caledon" },
      { name: "description", content: "Study rooms, sports pitches and practice studios across the University of Edinburgh — with live busyness estimates and gym membership info." },
    ],
  }),
  component: BookingsPage,
});

type Filter = "All" | Bookable["type"];

const FILTERS: { value: Filter; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { value: "All", label: "All", icon: LayoutGrid },
  { value: "Study room", label: "Study space", icon: BookOpen },
  { value: "Sports pitch", label: "Sports", icon: Trophy },
  { value: "Gym class", label: "Gym classes", icon: Dumbbell },
  { value: "Studio", label: "Studios", icon: Music },
];

const BUSY_CLASS: Record<Busyness, string> = {
  Quiet: "busy-quiet",
  Medium: "busy-medium",
  Busy: "busy-busy",
};

function BookingsPage() {
  const [filter, setFilter] = useState<Filter>("All");
  const list = BOOKABLES.filter((b) => filter === "All" || b.type === filter);

  return (
    <div className="p-6 lg:p-10 max-w-7xl mx-auto space-y-8">
      <header className="space-y-2">
        <Badge variant="secondary" className="rounded-full">
          Campus directory
        </Badge>
        <h1 className="text-4xl md:text-5xl font-display">Bookings</h1>
        <p className="text-muted-foreground max-w-2xl">
          What are you trying to book? We deep-link to the official booking page and show you when
          each space is usually quietest.
        </p>
      </header>

      <div className="flex flex-wrap gap-2">
        {FILTERS.map((f) => {
          const Icon = f.icon;
          const active = filter === f.value;
          return (
            <button
              key={f.value}
              onClick={() => setFilter(f.value)}
              className={`flex items-center gap-2 text-sm px-4 py-2 rounded-full border transition ${
                active
                  ? "bg-primary text-primary-foreground border-primary shadow-sm"
                  : "bg-card text-muted-foreground border-border hover:text-foreground hover:border-foreground/30"
              }`}
            >
              <Icon className="h-4 w-4" />
              {f.label}
            </button>
          );
        })}
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        {list.map((b) => (
          <Card key={b.id}>
            <CardHeader className="pb-2">
              <div className="flex items-start justify-between gap-2">
                <CardTitle className="font-display text-xl leading-tight">{b.name}</CardTitle>
                <Badge variant="outline">{b.type}</Badge>
              </div>
              <div className="text-xs text-muted-foreground">{b.building}</div>
            </CardHeader>
            <CardContent className="space-y-3">
              {b.hours && (
                <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  <Clock className="h-3 w-3" />
                  {b.hours}
                </div>
              )}
              <p className="text-sm text-muted-foreground">{b.note}</p>

              {b.busyByDay && (
                <div className="space-y-2 pt-1 border-t border-border/50">
                  <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    <Activity className="h-3 w-3" />
                    Typical busyness
                  </div>
                  <div className="grid grid-cols-7 gap-1">
                    {WEEKDAYS.map((d: Weekday) => {
                      const level = b.busyByDay?.[d];
                      return (
                        <div key={d} className="flex flex-col items-center gap-1">
                          <div className="text-[9px] uppercase tracking-wider text-muted-foreground">
                            {d}
                          </div>
                          <div
                            className={`w-full h-6 rounded-md flex items-center justify-center text-[10px] font-medium ${
                              level ? BUSY_CLASS[level] : "bg-muted text-muted-foreground/50"
                            }`}
                          >
                            {level ? level[0] : "–"}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                  {b.busyNote && <p className="text-xs text-muted-foreground italic">{b.busyNote}</p>}
                </div>
              )}

              <Button asChild variant="default" size="sm">
                <a href={b.bookingUrl} target="_blank" rel="noopener noreferrer">
                  Open booking page <ExternalLink className="h-3.5 w-3.5 ml-1.5" />
                </a>
              </Button>
            </CardContent>
          </Card>
        ))}
        {list.length === 0 && (
          <p className="text-sm text-muted-foreground">Nothing in this category yet.</p>
        )}
      </div>

      {/* Memberships section */}
      <section className="space-y-3 pt-4">
        <div className="space-y-1">
          <h2 className="font-display text-3xl">Memberships</h2>
          <p className="text-sm text-muted-foreground">
            Sort these before joining a club — Sports Union membership is required for BUCS,
            Pleasance is required for the gym, and intramural leagues are casual flat / course teams.
          </p>
        </div>
        <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-4">
          {MEMBERSHIPS.map((m) => (
            <Card key={m.id}>
              <CardHeader className="pb-2">
                <CardTitle className="font-display text-lg leading-tight">{m.name}</CardTitle>
                <div className="flex items-baseline gap-1">
                  <span className="text-xl font-display text-foreground">{m.price}</span>
                  <span className="text-xs text-muted-foreground">· {m.duration}</span>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-xs text-muted-foreground">{m.blurb}</p>
                <Button asChild size="sm" variant="outline" className="w-full">
                  <a href={m.url} target="_blank" rel="noopener noreferrer">
                    Sign up <ExternalLink className="h-3 w-3 ml-1.5" />
                  </a>
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>
    </div>
  );
}
