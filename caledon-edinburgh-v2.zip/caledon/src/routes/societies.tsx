import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Check, MapPin, Users, Info } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { SOCIETIES, type Society } from "@/data/societies";
import { usePlanner } from "@/lib/planner";

export const Route = createFileRoute("/societies")({
  head: () => ({
    meta: [
      { title: "Societies — Caledon" },
      { name: "description", content: "Browse Edinburgh societies and add their schedule to your planner in one tap. Sports Union and intramural sport included." },
    ],
  }),
  component: SocietiesPage,
});

const CATS: ("All" | Society["category"])[] = [
  "All",
  "Sport",
  "Academic",
  "Cultural",
  "Arts",
  "Social",
  "Volunteering",
];

function SocietiesPage() {
  const { joined, toggleSociety } = usePlanner();
  const [cat, setCat] = useState<(typeof CATS)[number]>("All");
  const [q, setQ] = useState("");

  const filtered = SOCIETIES.filter(
    (s) => (cat === "All" || s.category === cat) && s.name.toLowerCase().includes(q.toLowerCase()),
  );

  return (
    <div className="p-6 lg:p-10 max-w-7xl mx-auto space-y-8">
      <header className="space-y-2">
        <Badge variant="secondary" className="rounded-full">
          Curated for Edinburgh
        </Badge>
        <h1 className="text-4xl md:text-5xl font-display">Societies</h1>
        <p className="text-muted-foreground max-w-2xl">
          Edinburgh has over 300 societies. Here's a starter pack — joining one adds its weekly meets
          straight to your planner.
        </p>
      </header>

      {/* Sports Union / memberships explainer */}
      <Card className="bg-secondary/40 border-accent/30">
        <CardContent className="pt-5 flex flex-wrap items-start justify-between gap-3">
          <div className="flex items-start gap-2 flex-1 min-w-[260px]">
            <Info className="h-4 w-4 text-accent shrink-0 mt-0.5" />
            <div className="text-sm">
              <div className="font-medium text-foreground">Joining a sports club?</div>
              <p className="text-muted-foreground text-xs leading-relaxed">
                Sport clubs (rugby, hockey, climbing, etc.) usually require Sports Union membership on top of the club fee.
                Casual leagues run via Intra-Mural Sport — sign up a team with your flat. The Pleasance gym pass is separate again.
              </p>
            </div>
          </div>
          <Button asChild variant="outline" size="sm">
            <Link to="/bookings">See memberships</Link>
          </Button>
        </CardContent>
      </Card>

      <div className="flex flex-wrap items-center gap-3">
        <Input
          placeholder="Search societies…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          className="max-w-xs"
        />
        <div className="flex flex-wrap gap-1.5">
          {CATS.map((c) => (
            <button
              key={c}
              onClick={() => setCat(c)}
              className={`text-xs px-3 py-1.5 rounded-full border transition ${
                cat === c
                  ? "bg-primary text-primary-foreground border-primary"
                  : "bg-card text-muted-foreground border-border hover:text-foreground"
              }`}
            >
              {c}
            </button>
          ))}
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {filtered.map((s) => {
          const isJoined = joined.includes(s.id);
          return (
            <Card key={s.id} className={isJoined ? "border-accent" : ""}>
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between gap-2">
                  <CardTitle className="font-display text-xl leading-tight">{s.name}</CardTitle>
                  <Badge variant="outline" className="shrink-0">
                    {s.category}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-sm text-muted-foreground">{s.blurb}</p>
                <div className="space-y-1 text-xs text-muted-foreground">
                  {s.meets.map((m, i) => (
                    <div key={i} className="flex items-center gap-1.5">
                      <MapPin className="h-3 w-3" />
                      <span className="font-medium text-foreground">
                        {m.day} {m.start}–{m.end}
                      </span>
                      <span>· {m.venue}</span>
                    </div>
                  ))}
                </div>
                <div className="flex items-center justify-between pt-1">
                  <div className="text-xs text-muted-foreground flex items-center gap-1">
                    <Users className="h-3 w-3" /> {s.members.toLocaleString()} members
                  </div>
                  <Button
                    size="sm"
                    variant={isJoined ? "secondary" : "default"}
                    onClick={() => toggleSociety(s.id)}
                  >
                    {isJoined ? (
                      <>
                        <Check className="h-3.5 w-3.5 mr-1" /> Joined
                      </>
                    ) : (
                      "Add to week"
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
