import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport } from "ai";
import { Send, Sparkles } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";

export const Route = createFileRoute("/assistant")({
  head: () => ({
    meta: [
      { title: "Assistant — Caledon" },
      { name: "description", content: "Ask Caledon — your AI guide to Edinburgh student life, societies, halls and bookings." },
    ],
  }),
  component: AssistantPage,
});

const STARTERS = [
  "Where do most students go on a Wednesday?",
  "I'm Year 1 — which halls should I pick?",
  "Find me a quiet study room tomorrow",
  "What societies fit someone into hillwalking and film?",
];

function AssistantPage() {
  const [input, setInput] = useState("");
  const transport = new DefaultChatTransport({ api: "/api/chat" });
  const { messages, sendMessage, status } = useChat({ transport });
  const isLoading = status === "submitted" || status === "streaming";
  const taRef = useRef<HTMLTextAreaElement>(null);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages.length, status]);

  useEffect(() => {
    if (!isLoading) taRef.current?.focus();
  }, [isLoading]);

  const handleSend = (text: string) => {
    const t = text.trim();
    if (!t || isLoading) return;
    void sendMessage({ text: t });
    setInput("");
  };

  return (
    <div className="p-6 lg:p-10 max-w-3xl mx-auto space-y-6 flex flex-col h-[calc(100vh-3.5rem)]">
      <header className="space-y-2">
        <Badge variant="secondary" className="rounded-full">
          <Sparkles className="h-3 w-3 mr-1" /> Caledon AI
        </Badge>
        <h1 className="text-4xl font-display">Ask Caledon</h1>
        <p className="text-muted-foreground text-sm">
          Your in-app guide to Edinburgh — societies, halls, nightlife, bookings.
        </p>
      </header>

      <div className="flex-1 overflow-y-auto space-y-4 pr-1">
        {messages.length === 0 && (
          <div className="grid sm:grid-cols-2 gap-2">
            {STARTERS.map((s) => (
              <button
                key={s}
                onClick={() => handleSend(s)}
                className="text-left text-sm rounded-md border border-border bg-card p-3 hover:bg-accent/40 transition"
              >
                {s}
              </button>
            ))}
          </div>
        )}
        {messages.map((m) => {
          const text = m.parts
            .map((p) => (p.type === "text" ? p.text : ""))
            .join("");
          const isUser = m.role === "user";
          return (
            <div key={m.id} className={isUser ? "flex justify-end" : ""}>
              {isUser ? (
                <Card className="px-3 py-2 bg-primary text-primary-foreground max-w-[85%] text-sm">
                  {text}
                </Card>
              ) : (
                <div className="text-sm whitespace-pre-wrap leading-relaxed max-w-[90%]">
                  {text || <span className="text-muted-foreground italic">Thinking…</span>}
                </div>
              )}
            </div>
          );
        })}
        {isLoading && messages[messages.length - 1]?.role === "user" && (
          <div className="text-sm text-muted-foreground italic">Thinking…</div>
        )}
        <div ref={endRef} />
      </div>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSend(input);
        }}
        className="flex gap-2 items-end border-t border-border pt-3"
      >
        <Textarea
          ref={taRef}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              handleSend(input);
            }
          }}
          placeholder="Ask about societies, halls, nights out, study rooms…"
          rows={1}
          className="resize-none min-h-[44px]"
          autoFocus
        />
        <Button type="submit" size="icon" disabled={isLoading || !input.trim()}>
          <Send className="h-4 w-4" />
        </Button>
      </form>
    </div>
  );
}
