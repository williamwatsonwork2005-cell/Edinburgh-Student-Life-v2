import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { GraduationCap, ExternalLink, Calendar, FileText, Users, MessageSquare } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CAREER_EVENTS, type CareerEvent } from "@/data/careers";

export const Route = createFileRoute("/careers")({
  head: () => ({
    meta: [
      { title: "Careers — Caledon" },
      { name: "description", content: "Edinburgh Careers Service events, CV workshops, careers fairs and 1-to-1 appointments." },
    ],
  }),
  component: CareersPage,
});

const FILTERS: ("All" | CareerEvent["type"])[] = ["All", "Workshop", "Fair", "Talk", "1-to-1"];

const TYPE_ICON: Record<CareerEvent["type"], React.ComponentType<{ className?: string }>> = {
  Workshop: FileText,
  Fair: Users,
  Talk: MessageSquare,
  "1-to-1": Calendar,
};

function CareersPage() {
  const [filter, setFilter] = useState<(typeof FILTERS)[number]>("All");
  const list = CAREER_EVENTS.filter((e) => filter === "All" || e.type === filter);

  return (
    <div className="p-6 lg:p-10 max-w-7xl mx-auto space-y-8">
      <header className="space-y-2">
        <Badge variant="secondary" className="rounded-full">
          <GraduationCap className="h-3 w-3 mr-1" /> Career Builder
        </Badge>
        <h1 className="text-4xl md:text-5xl font-display">Careers</h1>
        <p className="text-muted-foreground max-w-2xl">
          CV workshops, careers fairs and 1-to-1 appointments with the University Careers Service.
          Bookings go through the official Careers portal — we just surface what's coming up.
        </p>
      </header>

      {/* Headline 1-to-1 CTA */}
      <Card className="border-accent/40 bg-accent/5">
        <CardContent className="pt-6 flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="font-display text-xl text-foreground">Book a 1-to-1 careers appointment</div>
            <div className="text-sm text-muted-foreground">
              30-min slots with a Career Consultant — CV review, application strategy, postgrad study, course choices.
            </div>
          </div>
          <Button asChild>
            <a href="https://www.ed.ac.uk/careers" target="_blank" rel="noopener noreferrer">
              Book on MyCareerHub <ExternalLink className="h-3.5 w-3.5 ml-1.5" />
            </a>
          </Button>
        </CardContent>
      </Card>

      <div className="flex flex-wrap gap-2">
        {FILTERS.map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`text-sm px-4 py-2 rounded-full border transition ${
              filter === f
                ? "bg-primary text-primary-foreground border-primary"
                : "bg-card text-muted-foreground border-border hover:text-foreground"
            }`}
          >
            {f}
          </button>
        ))}
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        {list.map((e) => {
          const Icon = TYPE_ICON[e.type];
          return (
            <Card key={e.id}>
              <CardHeader className="pb-2">
                <div className="flex items-start justify-between gap-2">
                  <CardTitle className="font-display text-xl leading-tight">{e.title}</CardTitle>
                  <Badge variant="outline">
                    <Icon className="h-3 w-3 mr-1" />
                    {e.type}
                  </Badge>
                </div>
                <div className="text-xs text-muted-foreground">{e.when}</div>
                <div className="text-xs text-muted-foreground">{e.venue}</div>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-sm text-muted-foreground">{e.blurb}</p>
                {e.bookingUrl && (
                  <Button asChild size="sm" variant="default">
                    <a href={e.bookingUrl} target="_blank" rel="noopener noreferrer">
                      Book / find out more <ExternalLink className="h-3 w-3 ml-1.5" />
                    </a>
                  </Button>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Card className="bg-muted/40">
        <CardContent className="pt-6 text-xs text-muted-foreground">
          Dates above are illustrative — for the live calendar, sign in to{" "}
          <a
            href="https://www.ed.ac.uk/careers"
            target="_blank"
            rel="noopener noreferrer"
            className="underline text-foreground"
          >
            MyCareerHub
          </a>{" "}
          with your UoE login.
        </CardContent>
      </Card>
    </div>
  );
}
