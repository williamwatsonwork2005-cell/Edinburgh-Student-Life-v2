import "@tanstack/react-start";
import { createFileRoute } from "@tanstack/react-router";
import { convertToModelMessages, streamText, type UIMessage } from "ai";
import { createLovableAiGatewayProvider } from "@/lib/ai-gateway";

const SYSTEM = `You are Caledon, an in-app assistant for University of Edinburgh students.
You help with:
- Finding societies, events, nightlife, and things to do (e.g. WhyNot Wednesdays on George Street, Sneaky Pete's gigs).
- Accommodation guidance: prospective and Year 1 students should look at Halls (Pollock, Kincaid's, Salisbury, Murano); Year 2+ should look at private flats in Marchmont, Newington, Tollcross, Bruntsfield, Leith.
- Booking study rooms, sports pitches and gym classes via the Bookings page.
- Student deals around campus.
Be concise, friendly, and Edinburgh-specific. Prefer 2-4 sentence answers with concrete venues/areas. Use markdown bullets when listing options.`;

type ChatRequestBody = { messages?: unknown };

export const Route = createFileRoute("/api/chat")({
  server: {
    handlers: {
      POST: async ({ request }: { request: Request }) => {
        const { messages } = (await request.json()) as ChatRequestBody;
        if (!Array.isArray(messages)) {
          return new Response("Messages are required", { status: 400 });
        }

        const key = process.env.LOVABLE_API_KEY;
        if (!key) return new Response("Missing LOVABLE_API_KEY", { status: 500 });

        const gateway = createLovableAiGatewayProvider(key);
        const model = gateway("google/gemini-3-flash-preview");

        const result = streamText({
          model,
          system: SYSTEM,
          messages: await convertToModelMessages(messages as UIMessage[]),
        });

        return result.toUIMessageStreamResponse({ originalMessages: messages as UIMessage[] });
      },
    },
  },
});
