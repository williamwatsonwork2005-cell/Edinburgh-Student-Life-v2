import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { LifeBuoy, ExternalLink, Phone, Heart, ShieldAlert, Bus, GraduationCap, AlertTriangle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CONTACTS, type Contact } from "@/data/safety";

export const Route = createFileRoute("/help")({
  head: () => ({
    meta: [
      { title: "Help & Safety — Caledon" },
      { name: "description", content: "Edinburgh student help — Nightline, Samaritans, safe taxis, University support and emergency numbers." },
    ],
  }),
  component: HelpPage,
});

const CAT_ICON: Record<Contact["category"], React.ComponentType<{ className?: string }>> = {
  "Mental health": Heart,
  Emergency: ShieldAlert,
  University: GraduationCap,
  Transport: Bus,
  "Sexual violence": ShieldAlert,
};

const CATEGORY_ORDER: Contact["category"][] = [
  "Emergency",
  "Mental health",
  "Sexual violence",
  "Transport",
  "University",
];

function HelpPage() {
  const [filter, setFilter] = useState<"All" | Contact["category"]>("All");
  const filtered = filter === "All" ? CONTACTS : CONTACTS.filter((c) => c.category === filter);

  const byCategory: Record<string, Contact[]> = {};
  for (const c of filtered) {
    (byCategory[c.category] ||= []).push(c);
  }

  return (
    <div className="p-6 lg:p-10 max-w-5xl mx-auto space-y-8">
      <header className="space-y-2">
        <Badge variant="secondary" className="rounded-full">
          <LifeBuoy className="h-3 w-3 mr-1" /> Support
        </Badge>
        <h1 className="text-4xl md:text-5xl font-display">Help & Safety</h1>
        <p className="text-muted-foreground max-w-2xl">
          Numbers, services and quick links — for getting home, getting heard, or getting help.
          For general University admin, head to MyEd.
        </p>
      </header>

      {/* Quick-action banner — most likely things you need at 2am */}
      <Card className="border-destructive/30 bg-destructive/5">
        <CardContent className="pt-6 grid sm:grid-cols-3 gap-3">
          <Button asChild variant="destructive" className="w-full justify-start h-auto py-3">
            <a href="tel:999">
              <AlertTriangle className="h-5 w-5 mr-2 shrink-0" />
              <div className="text-left">
                <div className="font-semibold leading-tight">Emergency</div>
                <div className="text-xs opacity-90">Call 999</div>
              </div>
            </a>
          </Button>
          <Button asChild variant="outline" className="w-full justify-start h-auto py-3 bg-card">
            <a href="tel:01315574444">
              <Heart className="h-5 w-5 mr-2 shrink-0 text-accent" />
              <div className="text-left">
                <div className="font-semibold leading-tight">Nightline</div>
                <div className="text-xs text-muted-foreground">0131 557 4444</div>
              </div>
            </a>
          </Button>
          <Button asChild variant="outline" className="w-full justify-start h-auto py-3 bg-card">
            <a href="tel:01312292468">
              <Bus className="h-5 w-5 mr-2 shrink-0 text-accent" />
              <div className="text-left">
                <div className="font-semibold leading-tight">Central Taxis</div>
                <div className="text-xs text-muted-foreground">0131 229 2468</div>
              </div>
            </a>
          </Button>
        </CardContent>
      </Card>

      {/* MyEd shortcut */}
      <Card className="bg-secondary/40">
        <CardContent className="pt-6 flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="font-display text-lg">General University enquiries</div>
            <div className="text-sm text-muted-foreground">Timetables, fees, IT, registry — it's all on MyEd.</div>
          </div>
          <Button asChild>
            <a href="https://www.myed.ed.ac.uk" target="_blank" rel="noopener noreferrer">
              Open MyEd <ExternalLink className="h-3.5 w-3.5 ml-1.5" />
            </a>
          </Button>
        </CardContent>
      </Card>

      <div className="flex flex-wrap gap-2">
        {(["All", ...CATEGORY_ORDER] as const).map((c) => (
          <button
            key={c}
            onClick={() => setFilter(c)}
            className={`text-xs px-3 py-1.5 rounded-full border transition ${
              filter === c
                ? "bg-primary text-primary-foreground border-primary"
                : "bg-card text-muted-foreground border-border hover:text-foreground"
            }`}
          >
            {c}
          </button>
        ))}
      </div>

      {CATEGORY_ORDER.filter((cat) => byCategory[cat]).map((cat) => {
        const Icon = CAT_ICON[cat];
        return (
          <section key={cat} className="space-y-3">
            <div className="flex items-center gap-2">
              <Icon className="h-5 w-5 text-primary" />
              <h2 className="font-display text-2xl">{cat}</h2>
            </div>
            <div className="grid gap-3 md:grid-cols-2">
              {byCategory[cat].map((c) => (
                <Card key={c.id} className={c.urgent ? "border-destructive/30" : ""}>
                  <CardHeader className="pb-2">
                    <div className="flex items-start justify-between gap-2">
                      <CardTitle className="font-display text-lg leading-tight">{c.name}</CardTitle>
                      {c.urgent && <Badge variant="destructive">Urgent</Badge>}
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <p className="text-sm text-muted-foreground">{c.description}</p>
                    <div className="flex flex-wrap gap-2">
                      {c.number.startsWith("0") || c.number === "999" || c.number === "111" || c.number === "101" || c.number === "116 123" ? (
                        <Button asChild size="sm" variant="default">
                          <a href={`tel:${c.number.replace(/\s/g, "")}`}>
                            <Phone className="h-3.5 w-3.5 mr-1.5" /> {c.number}
                          </a>
                        </Button>
                      ) : (
                        <Badge variant="secondary" className="text-xs">{c.number}</Badge>
                      )}
                      {c.url && (
                        <Button asChild size="sm" variant="outline">
                          <a href={c.url} target="_blank" rel="noopener noreferrer">
                            More info <ExternalLink className="h-3 w-3 ml-1.5" />
                          </a>
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </section>
        );
      })}

      <Card className="bg-muted/40">
        <CardContent className="pt-6 text-xs text-muted-foreground space-y-1">
          <p>
            Caledon is a student super-app. If you're in immediate danger, please call 999 directly.
          </p>
          <p>
            Phone numbers checked Nov 2025 — but always cross-reference with the official service if in doubt.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
