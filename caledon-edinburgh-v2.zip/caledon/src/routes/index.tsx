import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { AlertTriangle, Plus, Sparkles, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { WEEKDAYS, type Weekday, SOCIETIES } from "@/data/societies";
import { detectClashes, usePlanner, type Entry } from "@/lib/planner";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Planner — Caledon" },
      { name: "description", content: "Self-entered timetable with smart clash detection against your Edinburgh societies." },
    ],
  }),
  component: PlannerPage,
});

const KINDS: Entry["kind"][] = ["Lecture", "Tutorial", "Deadline", "Personal"];

function PlannerPage() {
  const { entries, joined, addEntry, removeEntry, hydrated } = usePlanner();
  const [form, setForm] = useState<{ title: string; kind: Entry["kind"]; day: Weekday; start: string; end: string; venue: string }>(
    { title: "", kind: "Lecture", day: "Mon", start: "09:00", end: "10:00", venue: "" }
  );

  const clashes = useMemo(() => detectClashes(entries, joined), [entries, joined]);

  const grid = useMemo(() => {
    const byDay: Record<Weekday, Entry[]> = { Mon: [], Tue: [], Wed: [], Thu: [], Fri: [], Sat: [], Sun: [] };
    for (const e of entries) byDay[e.day].push(e);
    Object.values(byDay).forEach((list) => list.sort((a, b) => a.start.localeCompare(b.start)));
    return byDay;
  }, [entries]);

  const summary = useMemo(() => {
    const days = WEEKDAYS.map((d) => {
      const own = entries.filter((e) => e.day === d && e.kind !== "Deadline").length;
      const socs = joined.flatMap((id) => SOCIETIES.find((s) => s.id === id)?.meets || []).filter((m) => m.day === d).length;
      return { day: d, total: own + socs };
    });
    const lightest = days.filter((d) => ["Mon", "Tue", "Wed", "Thu", "Fri"].includes(d.day)).sort((a, b) => a.total - b.total)[0];
    return lightest;
  }, [entries, joined]);

  return (
    <div className="p-6 lg:p-10 max-w-7xl mx-auto space-y-8">
      <header className="space-y-2">
        <Badge variant="secondary" className="rounded-full bg-secondary text-secondary-foreground">
          <Sparkles className="h-3 w-3 mr-1" /> Your week, your way
        </Badge>
        <h1 className="text-4xl md:text-5xl font-display text-foreground">Planner</h1>
        <p className="text-muted-foreground max-w-2xl">
          Drop in your lectures and tutorials. Caledon checks them against any Edinburgh societies you've joined and warns you about clashes before they bite.
        </p>
      </header>

      {/* Smart summary */}
      {hydrated && (entries.length > 0 || joined.length > 0) && (
        <Card className="border-accent/40 bg-accent/5">
          <CardContent className="pt-6 flex flex-wrap items-center gap-x-6 gap-y-2 text-sm">
            <div><span className="font-semibold text-foreground">{entries.length}</span> entries · <span className="font-semibold text-foreground">{joined.length}</span> societies</div>
            {summary && summary.total <= 1 && (
              <div className="text-muted-foreground">Lightest weekday: <span className="text-foreground font-medium">{summary.day}</span> — good for a society or a long lunch.</div>
            )}
            {clashes.length > 0 ? (
              <div className="flex items-center gap-2 text-destructive font-medium">
                <AlertTriangle className="h-4 w-4" /> {clashes.length} clash{clashes.length === 1 ? "" : "es"} detected
              </div>
            ) : (
              <div className="text-emerald-700 dark:text-emerald-400 font-medium">No clashes — you're in the clear.</div>
            )}
          </CardContent>
        </Card>
      )}

      <div className="grid gap-6 lg:grid-cols-[1fr_360px]">
        {/* Week grid */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="font-display text-2xl">This week</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-7 gap-2 text-sm">
              {WEEKDAYS.map((d) => (
                <div key={d} className="space-y-2">
                  <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground text-center">{d}</div>
                  <div className="space-y-1 min-h-32">
                    {grid[d].map((e) => (
                      <div key={e.id} className="group rounded-md border border-border bg-card p-2 text-left">
                        <div className="flex items-start justify-between gap-1">
                          <span className="text-xs font-medium leading-tight">{e.title}</span>
                          <button
                            onClick={() => removeEntry(e.id)}
                            className="opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-destructive"
                            aria-label="Remove"
                          >
                            <Trash2 className="h-3 w-3" />
                          </button>
                        </div>
                        <div className="text-[10px] text-muted-foreground mt-1">{e.start}–{e.end}</div>
                        <div className="text-[10px] text-accent font-medium">{e.kind}</div>
                      </div>
                    ))}
                    {joined
                      .flatMap((id) => {
                        const s = SOCIETIES.find((x) => x.id === id);
                        return s ? s.meets.filter((m) => m.day === d).map((m) => ({ s, m })) : [];
                      })
                      .map(({ s, m }, i) => (
                        <div key={`${s.id}-${i}`} className="rounded-md p-2 bg-thistle/15 border border-thistle/30">
                          <div className="text-xs font-medium leading-tight text-foreground">{s.name}</div>
                          <div className="text-[10px] text-muted-foreground mt-1">{m.start}–{m.end} · {m.venue}</div>
                          <div className="text-[10px] text-thistle font-medium">Society</div>
                        </div>
                      ))}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Add entry */}
        <Card>
          <CardHeader>
            <CardTitle className="font-display text-2xl">Add to your week</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="space-y-1.5">
              <Label htmlFor="title">Title</Label>
              <Input id="title" placeholder="e.g. Microeconomics Lecture" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1.5">
                <Label>Kind</Label>
                <Select value={form.kind} onValueChange={(v) => setForm({ ...form, kind: v as Entry["kind"] })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{KINDS.map((k) => <SelectItem key={k} value={k}>{k}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Day</Label>
                <Select value={form.day} onValueChange={(v) => setForm({ ...form, day: v as Weekday })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{WEEKDAYS.map((d) => <SelectItem key={d} value={d}>{d}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1.5">
                <Label htmlFor="start">Start</Label>
                <Input id="start" type="time" value={form.start} onChange={(e) => setForm({ ...form, start: e.target.value })} />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="end">End</Label>
                <Input id="end" type="time" value={form.end} onChange={(e) => setForm({ ...form, end: e.target.value })} />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="venue">Venue (optional)</Label>
              <Input id="venue" placeholder="e.g. Appleton Tower 2.14" value={form.venue} onChange={(e) => setForm({ ...form, venue: e.target.value })} />
            </div>
            <Button
              className="w-full"
              disabled={!form.title.trim()}
              onClick={() => {
                addEntry({ ...form, title: form.title.trim(), venue: form.venue.trim() || undefined });
                setForm({ ...form, title: "", venue: "" });
              }}
            >
              <Plus className="h-4 w-4 mr-1" /> Add entry
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Clash details */}
      {clashes.length > 0 && (
        <Card className="border-destructive/40">
          <CardHeader>
            <CardTitle className="font-display text-2xl text-destructive flex items-center gap-2">
              <AlertTriangle className="h-5 w-5" /> Conflicts
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            {clashes.map((c, i) => (
              <div key={i} className="flex flex-wrap items-center gap-2 p-3 rounded-md bg-destructive/5">
                <Badge variant="outline">{c.day}</Badge>
                <span><strong>{c.a.title}</strong> ({c.a.start}–{c.a.end})</span>
                <span className="text-muted-foreground">overlaps</span>
                <span><strong>{c.b.title}</strong> ({c.b.start}–{c.b.end})</span>
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
