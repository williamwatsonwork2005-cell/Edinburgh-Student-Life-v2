import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Tag } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { DEALS, type Deal } from "@/data/deals";

export const Route = createFileRoute("/deals")({
  head: () => ({
    meta: [
      { title: "Student deals — Caledon" },
      { name: "description", content: "Curated student discounts at independent and chain spots across Edinburgh." },
    ],
  }),
  component: DealsPage,
});

const CATS: ("All" | Deal["category"])[] = ["All", "Food", "Coffee", "Groceries", "Lifestyle", "Books"];

function DealsPage() {
  const [cat, setCat] = useState<(typeof CATS)[number]>("All");
  const list = DEALS.filter((d) => cat === "All" || d.category === cat);

  return (
    <div className="p-6 lg:p-10 max-w-7xl mx-auto space-y-8">
      <header className="space-y-2">
        <Badge variant="secondary" className="rounded-full">Just for Edinburgh students</Badge>
        <h1 className="text-4xl md:text-5xl font-display">Deals</h1>
        <p className="text-muted-foreground max-w-2xl">
          Genuine local discounts from places students actually go — independents on the Cowgate and Newington alongside the chains worth knowing.
        </p>
      </header>

      <div className="flex flex-wrap gap-1.5">
        {CATS.map((c) => (
          <button
            key={c}
            onClick={() => setCat(c)}
            className={`text-xs px-3 py-1.5 rounded-full border transition ${
              cat === c ? "bg-primary text-primary-foreground border-primary" : "bg-card text-muted-foreground border-border hover:text-foreground"
            }`}
          >
            {c}
          </button>
        ))}
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {list.map((d) => (
          <Card key={d.id} className="overflow-hidden">
            <div className="h-1.5 tartan-band" />
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between gap-2">
                <CardTitle className="font-display text-xl leading-tight">{d.name}</CardTitle>
                <Badge variant="outline">{d.area}</Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-2 text-accent font-semibold">
                <Tag className="h-4 w-4" /> {d.discount}
              </div>
              <p className="text-sm text-muted-foreground">{d.details}</p>
              <div className="text-xs text-muted-foreground">{d.category}</div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
