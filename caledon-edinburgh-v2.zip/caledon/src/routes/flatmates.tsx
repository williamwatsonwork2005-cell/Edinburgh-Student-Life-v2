import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Users, Check, Sparkles, Edit3, Heart, MapPin } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";
import {
  AREA_OPTIONS,
  DEFAULT_SURVEY,
  MOCK_FLATMATES,
  compatibility,
  useFlatmateSurvey,
  type FlatmateSurvey,
} from "@/lib/flatmates";

export const Route = createFileRoute("/flatmates")({
  head: () => ({
    meta: [
      { title: "Flatmate finder — Caledon" },
      { name: "description", content: "Find compatible flatmates at the University of Edinburgh — safer than Facebook Marketplace, matched by lifestyle." },
    ],
  }),
  component: FlatmatesPage,
});

function FlatmatesPage() {
  const { survey, setSurvey, clearSurvey, hydrated } = useFlatmateSurvey();
  const [editing, setEditing] = useState(false);

  if (!hydrated) return null;

  if (!survey || editing) {
    return (
      <SurveyForm
        initial={survey ?? DEFAULT_SURVEY}
        onSave={(s) => {
          setSurvey(s);
          setEditing(false);
        }}
        onCancel={survey ? () => setEditing(false) : undefined}
      />
    );
  }

  return (
    <MatchesView
      survey={survey}
      onEdit={() => setEditing(true)}
      onClear={() => {
        clearSurvey();
        setEditing(false);
      }}
    />
  );
}

function SurveyForm({
  initial,
  onSave,
  onCancel,
}: {
  initial: FlatmateSurvey;
  onSave: (s: FlatmateSurvey) => void;
  onCancel?: () => void;
}) {
  const [s, setS] = useState<FlatmateSurvey>(initial);
  const toggle = <K extends keyof FlatmateSurvey>(k: K, v: FlatmateSurvey[K]) =>
    setS({ ...s, [k]: v });
  const toggleArea = (a: string) =>
    setS({ ...s, areas: s.areas.includes(a) ? s.areas.filter((x) => x !== a) : [...s.areas, a] });

  const valid = s.name.trim().length > 0 && s.year.trim().length > 0;

  return (
    <div className="p-6 lg:p-10 max-w-3xl mx-auto space-y-8">
      <header className="space-y-2">
        <Badge variant="secondary" className="rounded-full">
          <Sparkles className="h-3 w-3 mr-1" /> Tell us about you
        </Badge>
        <h1 className="text-4xl md:text-5xl font-display">Flatmate finder</h1>
        <p className="text-muted-foreground">
          Fill this in to see other Edinburgh students looking for the same kind of flat. Match scores
          are based on lifestyle compatibility — sleep, tidiness, noise, budget, area.
        </p>
      </header>

      <Card>
        <CardHeader>
          <CardTitle className="font-display text-2xl">About you</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid sm:grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="name">First name</Label>
              <Input id="name" value={s.name} onChange={(e) => toggle("name", e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="year">Year of study</Label>
              <Input id="year" placeholder="e.g. Year 2, Postgrad" value={s.year} onChange={(e) => toggle("year", e.target.value)} />
            </div>
            <div className="space-y-1.5 sm:col-span-2">
              <Label htmlFor="course">Course</Label>
              <Input id="course" placeholder="e.g. Medicine" value={s.course} onChange={(e) => toggle("course", e.target.value)} />
            </div>
            <div className="space-y-1.5 sm:col-span-2">
              <Label htmlFor="bio">Short bio</Label>
              <Textarea
                id="bio"
                placeholder="A line or two about you and what you're looking for."
                value={s.bio}
                onChange={(e) => toggle("bio", e.target.value)}
                rows={3}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="font-display text-2xl">Lifestyle</CardTitle>
        </CardHeader>
        <CardContent className="space-y-5">
          <ChipRow
            label="Bedtime"
            value={s.sleep}
            onChange={(v) => toggle("sleep", v as FlatmateSurvey["sleep"])}
            options={[
              { value: "early", label: "Early to bed" },
              { value: "either", label: "Don't mind" },
              { value: "late", label: "Night owl" },
            ]}
          />
          <ChipRow
            label="Social at home"
            value={s.social}
            onChange={(v) => toggle("social", v as FlatmateSurvey["social"])}
            options={[
              { value: "quiet", label: "Quiet flat" },
              { value: "moderate", label: "Some socialising" },
              { value: "loud", label: "Hosts welcome" },
            ]}
          />
          <ChipRow
            label="Tidiness"
            value={s.tidiness}
            onChange={(v) => toggle("tidiness", v as FlatmateSurvey["tidiness"])}
            options={[
              { value: "tidy", label: "Always tidy" },
              { value: "average", label: "Average" },
              { value: "relaxed", label: "Relaxed" },
            ]}
          />
          <ChipRow
            label="Cooking"
            value={s.cooking}
            onChange={(v) => toggle("cooking", v as FlatmateSurvey["cooking"])}
            options={[
              { value: "alone", label: "Cook alone" },
              { value: "either", label: "No preference" },
              { value: "share", label: "Share meals" },
            ]}
          />
          <ChipRow
            label="Smoking"
            value={s.smoke}
            onChange={(v) => toggle("smoke", v as FlatmateSurvey["smoke"])}
            options={[
              { value: "no", label: "No smoking" },
              { value: "ok-outside", label: "OK outside" },
              { value: "yes", label: "Fine with it" },
            ]}
          />
          <ChipRow
            label="Pets"
            value={s.pets}
            onChange={(v) => toggle("pets", v as FlatmateSurvey["pets"])}
            options={[
              { value: "no", label: "No pets" },
              { value: "no-pref", label: "No preference" },
              { value: "yes", label: "Pet-friendly" },
            ]}
          />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="font-display text-2xl">Budget & area</CardTitle>
        </CardHeader>
        <CardContent className="space-y-5">
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Budget per person, per month</span>
              <span className="font-semibold">£{s.budgetPcm}</span>
            </div>
            <Slider
              value={[s.budgetPcm]}
              min={400}
              max={1200}
              step={20}
              onValueChange={(v) => toggle("budgetPcm", v[0])}
            />
          </div>
          <div className="space-y-2">
            <Label>Preferred areas (pick any that work)</Label>
            <div className="flex flex-wrap gap-2">
              {AREA_OPTIONS.map((a) => {
                const active = s.areas.includes(a);
                return (
                  <button
                    key={a}
                    type="button"
                    onClick={() => toggleArea(a)}
                    className={`text-xs px-3 py-1.5 rounded-full border transition ${
                      active
                        ? "bg-primary text-primary-foreground border-primary"
                        : "bg-card text-muted-foreground border-border hover:text-foreground"
                    }`}
                  >
                    {a}
                  </button>
                );
              })}
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex items-center justify-between gap-3">
        <p className="text-xs text-muted-foreground">
          Your survey is saved locally on your device. Anyone you match with sees only what you choose
          to share.
        </p>
        <div className="flex gap-2 shrink-0">
          {onCancel && (
            <Button variant="ghost" onClick={onCancel}>
              Cancel
            </Button>
          )}
          <Button onClick={() => valid && onSave(s)} disabled={!valid}>
            Find matches
          </Button>
        </div>
      </div>
    </div>
  );
}

function ChipRow<T extends string>({
  label,
  value,
  options,
  onChange,
}: {
  label: string;
  value: T;
  options: { value: T; label: string }[];
  onChange: (v: T) => void;
}) {
  return (
    <div className="space-y-2">
      <Label>{label}</Label>
      <div className="flex flex-wrap gap-2">
        {options.map((o) => {
          const active = o.value === value;
          return (
            <button
              key={o.value}
              type="button"
              onClick={() => onChange(o.value)}
              className={`text-xs px-3 py-1.5 rounded-full border transition ${
                active
                  ? "bg-primary text-primary-foreground border-primary"
                  : "bg-card text-muted-foreground border-border hover:text-foreground"
              }`}
            >
              {o.label}
            </button>
          );
        })}
      </div>
    </div>
  );
}

function MatchesView({
  survey,
  onEdit,
  onClear,
}: {
  survey: FlatmateSurvey;
  onEdit: () => void;
  onClear: () => void;
}) {
  const [liked, setLiked] = useState<Set<string>>(new Set());

  const matches = useMemo(
    () =>
      MOCK_FLATMATES.map((p) => ({ ...p, score: compatibility(survey, p) })).sort(
        (a, b) => b.score - a.score,
      ),
    [survey],
  );

  return (
    <div className="p-6 lg:p-10 max-w-7xl mx-auto space-y-8">
      <header className="flex flex-wrap items-start justify-between gap-3">
        <div className="space-y-2">
          <Badge variant="secondary" className="rounded-full">
            <Users className="h-3 w-3 mr-1" /> Hi {survey.name || "there"}
          </Badge>
          <h1 className="text-4xl md:text-5xl font-display">Your matches</h1>
          <p className="text-muted-foreground max-w-2xl">
            Ranked by compatibility based on your survey. Higher score = closer lifestyle fit. Tap the heart
            to shortlist someone to reach out to.
          </p>
        </div>
        <div className="flex gap-2 shrink-0">
          <Button variant="outline" size="sm" onClick={onEdit}>
            <Edit3 className="h-3.5 w-3.5 mr-1.5" /> Edit survey
          </Button>
          <Button variant="ghost" size="sm" onClick={onClear}>
            Clear
          </Button>
        </div>
      </header>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {matches.map((m) => {
          const isLiked = liked.has(m.id);
          return (
            <Card key={m.id} className={isLiked ? "border-accent" : ""}>
              <CardHeader className="pb-2">
                <div className="flex items-start justify-between gap-2">
                  <CardTitle className="font-display text-xl leading-tight">{m.name}</CardTitle>
                  <button
                    onClick={() => {
                      const next = new Set(liked);
                      if (next.has(m.id)) next.delete(m.id);
                      else next.add(m.id);
                      setLiked(next);
                    }}
                    aria-label={isLiked ? "Unshortlist" : "Shortlist"}
                    className={`p-1.5 rounded-full transition ${
                      isLiked ? "text-accent" : "text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    <Heart className={`h-4 w-4 ${isLiked ? "fill-current" : ""}`} />
                  </button>
                </div>
                <div className="text-xs text-muted-foreground">
                  {m.year} · {m.course}
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <CompatBar score={m.score} />
                <p className="text-sm text-muted-foreground">{m.bio}</p>
                <div className="grid grid-cols-2 gap-1 text-[11px] text-muted-foreground">
                  <Trait label="Sleep" value={m.sleep} mine={survey.sleep} />
                  <Trait label="Social" value={m.social} mine={survey.social} />
                  <Trait label="Tidy" value={m.tidiness} mine={survey.tidiness} />
                  <Trait label="Cook" value={m.cooking} mine={survey.cooking} />
                </div>
                <div className="flex flex-wrap gap-1.5">
                  <Badge variant="secondary" className="text-[11px]">£{m.budgetPcm} pcm</Badge>
                  {m.areas.slice(0, 3).map((a) => (
                    <Badge key={a} variant="outline" className="text-[11px]">
                      <MapPin className="h-2.5 w-2.5 mr-0.5" />
                      {a}
                    </Badge>
                  ))}
                </div>
                <Button size="sm" variant={isLiked ? "default" : "outline"} className="w-full">
                  Message via UoE email
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Card className="bg-muted/40">
        <CardContent className="pt-6 text-xs text-muted-foreground">
          <strong className="text-foreground">Safer than Marketplace.</strong> Caledon only matches verified UoE
          students, and contact happens via University email — not third-party messengers. Match scores are an
          estimate; meet in person before signing anything.
        </CardContent>
      </Card>
    </div>
  );
}

function Trait({
  label,
  value,
  mine,
}: {
  label: string;
  value: string;
  mine: string;
}) {
  const matches = value === mine || mine === "either" || mine === "no-pref" || value === "either" || value === "no-pref";
  return (
    <div className="flex items-center gap-1">
      {matches && <Check className="h-3 w-3 text-emerald-600" />}
      <span className="text-muted-foreground">{label}:</span>
      <span className="text-foreground capitalize">{value.replace("-", " ")}</span>
    </div>
  );
}

function CompatBar({ score }: { score: number }) {
  const tier = score >= 75 ? "Great fit" : score >= 55 ? "Good fit" : score >= 35 ? "Could work" : "Not ideal";
  const tone =
    score >= 75 ? "text-emerald-700" : score >= 55 ? "text-accent-foreground" : score >= 35 ? "text-muted-foreground" : "text-destructive";
  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between text-xs">
        <span className={`font-semibold ${tone}`}>{tier}</span>
        <span className="text-muted-foreground">{score}% match</span>
      </div>
      <div className="h-1.5 rounded-full bg-muted overflow-hidden">
        <div
          className="h-full bg-primary transition-all"
          style={{ width: `${score}%` }}
        />
      </div>
    </div>
  );
}
