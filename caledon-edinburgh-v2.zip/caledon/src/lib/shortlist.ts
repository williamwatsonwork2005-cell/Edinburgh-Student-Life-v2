import { useEffect, useState } from "react";

export type Rating = { location: number; quality: number; price: number };

const LIKES_KEY = "caledon.shortlist";
const RATINGS_KEY = "caledon.ratings";

function read<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

export function useShortlist() {
  const [likes, setLikes] = useState<string[]>([]);
  const [ratings, setRatings] = useState<Record<string, Rating>>({});
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    setLikes(read<string[]>(LIKES_KEY, []));
    setRatings(read<Record<string, Rating>>(RATINGS_KEY, {}));
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (hydrated) window.localStorage.setItem(LIKES_KEY, JSON.stringify(likes));
  }, [likes, hydrated]);
  useEffect(() => {
    if (hydrated) window.localStorage.setItem(RATINGS_KEY, JSON.stringify(ratings));
  }, [ratings, hydrated]);

  const toggleLike = (id: string) =>
    setLikes((cur) => (cur.includes(id) ? cur.filter((x) => x !== id) : [...cur, id]));

  const setRating = (id: string, axis: keyof Rating, value: number) =>
    setRatings((cur) => {
      const prev = cur[id] ?? { location: 0, quality: 0, price: 0 };
      return { ...cur, [id]: { ...prev, [axis]: value } };
    });

  const overall = (id: string): number => {
    const r = ratings[id];
    if (!r) return 0;
    const filled = [r.location, r.quality, r.price].filter((v) => v > 0);
    if (filled.length === 0) return 0;
    return filled.reduce((a, b) => a + b, 0) / filled.length;
  };

  return { likes, ratings, toggleLike, setRating, overall, hydrated };
}
