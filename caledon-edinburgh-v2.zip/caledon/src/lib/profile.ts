import { useEffect, useState } from "react";

export type StudentStage =
  | "prospective"
  | "year1"
  | "year2"
  | "year3"
  | "year4plus"
  | "postgrad";

export type Profile = {
  stage: StudentStage;
  name?: string;
};

export const STAGE_LABEL: Record<StudentStage, string> = {
  prospective: "Prospective — looking at halls",
  year1: "Year 1 — going into halls",
  year2: "Year 2 — first private flat",
  year3: "Year 3",
  year4plus: "Year 4+ / Honours",
  postgrad: "Postgraduate",
};

const KEY = "caledon.profile";

export function useProfile() {
  const [profile, setProfileState] = useState<Profile | null>(null);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      const raw = window.localStorage.getItem(KEY);
      if (raw) setProfileState(JSON.parse(raw));
    } catch {
      // ignore
    }
    setHydrated(true);
  }, []);

  const setProfile = (p: Profile) => {
    setProfileState(p);
    if (typeof window !== "undefined") {
      window.localStorage.setItem(KEY, JSON.stringify(p));
    }
  };

  const clearProfile = () => {
    setProfileState(null);
    if (typeof window !== "undefined") window.localStorage.removeItem(KEY);
  };

  return { profile, setProfile, clearProfile, hydrated };
}
