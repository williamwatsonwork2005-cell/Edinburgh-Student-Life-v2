import { useEffect, useState } from "react";

export type FlatmateSurvey = {
  sleep: "early" | "late" | "either"; // bedtime preference
  social: "quiet" | "moderate" | "loud"; // social at home
  tidiness: "tidy" | "average" | "relaxed";
  cooking: "alone" | "share" | "either";
  smoke: "yes" | "no" | "ok-outside";
  pets: "yes" | "no" | "no-pref";
  budgetPcm: number;
  areas: string[];
  year: string;
  course: string;
  name: string;
  bio: string;
};

export const DEFAULT_SURVEY: FlatmateSurvey = {
  sleep: "either",
  social: "moderate",
  tidiness: "average",
  cooking: "either",
  smoke: "no",
  pets: "no-pref",
  budgetPcm: 650,
  areas: [],
  year: "",
  course: "",
  name: "",
  bio: "",
};

const KEY = "caledon.flatmateSurvey";

export function useFlatmateSurvey() {
  const [survey, setSurveyState] = useState<FlatmateSurvey | null>(null);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      const raw = window.localStorage.getItem(KEY);
      if (raw) setSurveyState(JSON.parse(raw));
    } catch {
      // ignore
    }
    setHydrated(true);
  }, []);

  const setSurvey = (s: FlatmateSurvey) => {
    setSurveyState(s);
    if (typeof window !== "undefined") window.localStorage.setItem(KEY, JSON.stringify(s));
  };

  const clearSurvey = () => {
    setSurveyState(null);
    if (typeof window !== "undefined") window.localStorage.removeItem(KEY);
  };

  return { survey, setSurvey, clearSurvey, hydrated };
}

// Mock pool of other students looking for flatmates
export type FlatmateProfile = FlatmateSurvey & { id: string };

export const MOCK_FLATMATES: FlatmateProfile[] = [
  {
    id: "a", name: "Anna", year: "Year 2", course: "Medicine",
    sleep: "early", social: "moderate", tidiness: "tidy", cooking: "share",
    smoke: "no", pets: "no-pref", budgetPcm: 650, areas: ["Marchmont", "Newington"],
    bio: "Looking for chilled flatmates for 2026/27. I cook a lot, happy to share. Studied here a year already.",
  },
  {
    id: "b", name: "Marcus", year: "Year 3", course: "Economics",
    sleep: "late", social: "loud", tidiness: "relaxed", cooking: "alone",
    smoke: "ok-outside", pets: "no", budgetPcm: 720, areas: ["Tollcross", "Bruntsfield"],
    bio: "Up late, into football and going out. Looking for a 3-bed with similar energy.",
  },
  {
    id: "c", name: "Priya", year: "Year 2", course: "Law",
    sleep: "early", social: "quiet", tidiness: "tidy", cooking: "alone",
    smoke: "no", pets: "no", budgetPcm: 600, areas: ["Marchmont", "Bruntsfield"],
    bio: "Quiet flat please — I work long hours and value sleep. Tea drinker.",
  },
  {
    id: "d", name: "Jamie", year: "Year 2", course: "Physics",
    sleep: "late", social: "moderate", tidiness: "average", cooking: "share",
    smoke: "no", pets: "yes", budgetPcm: 670, areas: ["Marchmont", "Newington", "Tollcross"],
    bio: "Easy-going, into climbing and cooking. Would love a flat that allows a cat.",
  },
  {
    id: "e", name: "Sofia", year: "Year 4", course: "English Lit",
    sleep: "early", social: "quiet", tidiness: "tidy", cooking: "share",
    smoke: "no", pets: "no-pref", budgetPcm: 700, areas: ["Stockbridge", "Bruntsfield"],
    bio: "Final year, want a peaceful flat to write a dissertation. Will absolutely take my turn cooking.",
  },
  {
    id: "f", name: "Tom", year: "Year 2", course: "Geosciences",
    sleep: "either", social: "moderate", tidiness: "average", cooking: "either",
    smoke: "no", pets: "no-pref", budgetPcm: 640, areas: ["Marchmont", "Newington", "Tollcross"],
    bio: "Spend weekends in the hills. Easy flatmate — I'm rarely in.",
  },
  {
    id: "g", name: "Rachel", year: "Year 3", course: "Business",
    sleep: "late", social: "loud", tidiness: "average", cooking: "share",
    smoke: "no", pets: "no", budgetPcm: 750, areas: ["Bruntsfield", "Stockbridge", "Leith Walk"],
    bio: "Looking for fun, sociable flatmates for next year. I host dinners.",
  },
  {
    id: "h", name: "Daniel", year: "Postgrad", course: "Informatics",
    sleep: "late", social: "quiet", tidiness: "tidy", cooking: "alone",
    smoke: "no", pets: "no-pref", budgetPcm: 850, areas: ["Newington", "Marchmont"],
    bio: "Quiet, focused on PhD work. Looking for an MSc/PhD-only flat ideally.",
  },
];

// Compatibility scoring 0–100
export function compatibility(me: FlatmateSurvey, them: FlatmateSurvey): number {
  let score = 0;
  let weight = 0;

  const match = (a: string, b: string, w: number, eitherMatches = false) => {
    weight += w;
    if (a === b) score += w;
    else if (eitherMatches && (a === "either" || b === "either")) score += w * 0.7;
    else if (a === "no-pref" || b === "no-pref") score += w * 0.6;
  };

  match(me.sleep, them.sleep, 18, true);
  match(me.social, them.social, 20);
  match(me.tidiness, them.tidiness, 22);
  match(me.cooking, them.cooking, 8, true);
  match(me.smoke, them.smoke, 15);
  match(me.pets, them.pets, 7);

  // Budget proximity — within £100 is fine
  weight += 5;
  const diff = Math.abs(me.budgetPcm - them.budgetPcm);
  if (diff <= 100) score += 5;
  else if (diff <= 200) score += 3;
  else if (diff <= 300) score += 1;

  // Shared area preference
  weight += 5;
  const overlap = me.areas.filter((a) => them.areas.includes(a)).length;
  if (overlap > 0) score += Math.min(5, overlap * 2);

  return Math.round((score / weight) * 100);
}

export const AREA_OPTIONS = [
  "Marchmont",
  "Newington",
  "Tollcross",
  "Bruntsfield",
  "Stockbridge",
  "Leith Walk",
  "Old Town",
];
