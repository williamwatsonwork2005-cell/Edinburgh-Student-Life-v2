import { useEffect, useState } from "react";
import type { Weekday } from "@/data/societies";
import { SOCIETIES } from "@/data/societies";

export type Entry = {
  id: string;
  title: string;
  kind: "Lecture" | "Tutorial" | "Deadline" | "Personal";
  day: Weekday;
  start: string; // HH:MM
  end: string;
  venue?: string;
};

const ENTRIES_KEY = "caledon.entries";
const SOCS_KEY = "caledon.societies";

function read<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

export function usePlanner() {
  const [entries, setEntries] = useState<Entry[]>([]);
  const [joined, setJoined] = useState<string[]>([]);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    setEntries(read<Entry[]>(ENTRIES_KEY, []));
    setJoined(read<string[]>(SOCS_KEY, []));
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (hydrated) window.localStorage.setItem(ENTRIES_KEY, JSON.stringify(entries));
  }, [entries, hydrated]);
  useEffect(() => {
    if (hydrated) window.localStorage.setItem(SOCS_KEY, JSON.stringify(joined));
  }, [joined, hydrated]);

  const addEntry = (e: Omit<Entry, "id">) =>
    setEntries((cur) => [...cur, { ...e, id: crypto.randomUUID() }]);
  const removeEntry = (id: string) => setEntries((cur) => cur.filter((e) => e.id !== id));
  const toggleSociety = (id: string) =>
    setJoined((cur) => (cur.includes(id) ? cur.filter((x) => x !== id) : [...cur, id]));

  return { entries, joined, addEntry, removeEntry, toggleSociety, hydrated };
}

const toMin = (t: string) => {
  const [h, m] = t.split(":").map(Number);
  return h * 60 + m;
};

export type Clash = {
  day: Weekday;
  a: { title: string; start: string; end: string };
  b: { title: string; start: string; end: string };
};

export function detectClashes(entries: Entry[], joinedIds: string[]): Clash[] {
  const blocks: { day: Weekday; start: number; end: number; title: string; startStr: string; endStr: string }[] = [];
  for (const e of entries) {
    if (e.kind === "Deadline") continue;
    blocks.push({ day: e.day, start: toMin(e.start), end: toMin(e.end), title: e.title, startStr: e.start, endStr: e.end });
  }
  for (const id of joinedIds) {
    const soc = SOCIETIES.find((s) => s.id === id);
    if (!soc) continue;
    for (const m of soc.meets) {
      blocks.push({ day: m.day, start: toMin(m.start), end: toMin(m.end), title: soc.name, startStr: m.start, endStr: m.end });
    }
  }
  const clashes: Clash[] = [];
  for (let i = 0; i < blocks.length; i++) {
    for (let j = i + 1; j < blocks.length; j++) {
      const a = blocks[i], b = blocks[j];
      if (a.day !== b.day) continue;
      if (a.start < b.end && b.start < a.end) {
        clashes.push({
          day: a.day,
          a: { title: a.title, start: a.startStr, end: a.endStr },
          b: { title: b.title, start: b.startStr, end: b.endStr },
        });
      }
    }
  }
  return clashes;
}
